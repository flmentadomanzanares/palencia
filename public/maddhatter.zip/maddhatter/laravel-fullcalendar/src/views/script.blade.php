<script>
    window.onload=function(){
        $('#calendar-{{ $id }}').fullCalendar({!! $options !!});
    };
</script>
