<?php namespace Illuminate\Container;

use Exception;

class BindingResolutionException extends Exception {}
