<?php namespace Illuminate\Foundation\Auth;

use Illuminate\Http\Request;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Contracts\Auth\Registrar;
use Illuminate\Support\Facades\Mail;

trait AuthenticatesAndRegistersUsers
{

    /**
     * The Guard implementation.
     *
     * @var \Illuminate\Contracts\Auth\Guard
     */
    protected $auth;

    /**
     * The registrar implementation.
     *
     * @var \Illuminate\Contracts\Auth\Registrar
     */
    protected $registrar;

    /**
     * Show the application registration form.
     *
     * @return \Illuminate\Http\Response
     */
    public function getRegister()
    {
        return view('auth.register');
    }

    /**
     * Handle a registration request for the application.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function postRegister(Request $request)
    {
        $validator = $this->registrar->validator($request->all());
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }
        $campos=$request->all();
        $campos['activo']="1";
        $campos['codigo_confirmacion'] = str_random(30);
        Mail::send('email.verify', $campos['codigo_confirmacion'], function($message) use ( $campos) {
            $message->to($campos['email'], $campos['name'])
                ->subject('Verifica tu dirección de correos.');
        });
        \Flash::message('Gracias por darte de alta, Por favor verifica tu cuenta de correos.');
        return Redirect('/');

        //Antigüo
        //$this->auth->login($this->registrar->create($request->all()));
        //return redirect($this->redirectPath());
    }

    /**
     * Show the application login form.
     *
     * @return \Illuminate\Http\Response
     */
    public function getLogin()
    {
        return view('invitado');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email', 'password' => 'required'
        ]);
        $credentials = $request->only('email', 'password');
        $error = $this->auth->attempt($credentials, $request->has('remember'));
        switch ($error) {
            case 0:
                return redirect()->intended($this->redirectPath());
            case -1:
            case 1:
                return redirect($this->loginPath())
                    ->withInput($request->only('email', 'remember'))
                    ->withErrors([
                        'email' => $this->getFailedLoginMessage(),
                    ]);
            case 2:
                return redirect($this->loginPath())
                    ->withInput($request->only('email', 'remember'))
                    ->withErrors([
                        'email' => $this->getNoActiveUserMessage(),
                    ]);
            case 3:
                return redirect($this->loginPath())
                    ->withInput($request->only('email', 'remember'))
                    ->withErrors([
                        'email' => $this->getNoConfirmationMessage(),
                    ]);
        }
    }
    /**
     * Get no confirmation  message.
     *
     * @return string
     */
    private function getNoConfirmationMessage()
    {
        return 'valida tu cuenta desde tu email.';
    }

    /**
     * Get the failed login message.
     *
     * @return string
     */
    private function getNoActiveUserMessage()
    {
        return 'El usuario no está activo, ponte en contacto con el administrador.';
    }

    /**
     * Get the failed login message.
     *
     * @return string
     */
    protected function getFailedLoginMessage()
    {
        return 'email y/o password no coinciden.';
    }

    /**
     * Log the user out of the application.
     *
     * @return \Illuminate\Http\Response
     */
    public function getLogout()
    {
        $this->auth->logout();

        return redirect(property_exists($this, 'redirectAfterLogout') ? $this->redirectAfterLogout : '/');
    }

    /**
     * Get the post register / login redirect path.
     *
     * @return string
     */
    public function redirectPath()
    {
        if (property_exists($this, 'redirectPath')) {
            return $this->redirectPath;
        }

        return property_exists($this, 'redirectTo') ? $this->redirectTo : 'inicio';
    }

    /**
     * Get the path to the login route.
     *
     * @return string
     */
    public function loginPath()
    {
        return property_exists($this, 'loginPath') ? $this->loginPath : '/';
    }

}
