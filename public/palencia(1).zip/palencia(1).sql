-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-02-2016 a las 01:08:22
-- Versión del servidor: 10.0.17-MariaDB
-- Versión de PHP: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `palencia`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `colores`
--

CREATE TABLE `colores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `nombre_color` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `codigo_color` varchar(7) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `colores`
--

INSERT INTO `colores` (`id`, `nombre_color`, `codigo_color`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'black', '#000000', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(2, 'blue', '#0000ff', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(3, 'brown', '#a52a2a', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(4, 'cadetblue', '#5f9ea0', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(5, 'chocolate', '#d2691e', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(6, 'coral', '#ff7f50', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(7, 'cornflowerblue', '#6495ed', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(8, 'crimson', '#dc143c', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(9, 'darkgoldenrod', '#b8860b', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(10, 'darkgray', '#a9a9a9', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(11, 'darkgreen', '#006400', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(12, 'darkkhaki', '#bdb76b', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(13, 'darkmagenta', '#8b008b', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(14, 'darkolivegreen', '#556b2f', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(15, 'darkorange', '#ff8c00', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(16, 'darkseagreen', '#8fbc8f', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(17, 'darkslateblue', '#483d8b', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(18, 'deeppink', '#ff1493', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(19, 'dimgray', '#696969', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(20, 'firebrick', '#b22222', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(21, 'goldenrod', '#daa520', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(22, 'green', '#008000', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(23, 'indianred', '#cd5c5c', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(24, 'indigo', '#4b0082', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(25, 'ivory', '#fffff0', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(26, 'lightblue', '#add8e6', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(27, 'lightgray', '#d3d3d3', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(28, 'lightgreen', '#90ee90', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(29, 'lightsalmon', '#ffa07a', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(30, 'lightsteelblue', '#b0c4de', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(31, 'lightyellow', '#ffffe0', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(32, 'lime', '#00ff00', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(33, 'limegreen', '#32cd32', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(34, 'magenta', '#ff00ff', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(35, 'maroon', '#800000', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(36, 'mediumaquamarine', '#66cdaa', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(37, 'mediumblue', '#0000cd', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(38, 'mediumorchid', '#ba55d3', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(39, 'mediumseagreen', '#3cb371', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(40, 'mediumspringgreen', '#00fa9a', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(41, 'mediumvioletred', '#c71585', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(42, 'navy', '#000080', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(43, 'olive', '#808000', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(44, 'orangered', '#ff4500', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(45, 'orchid', '#da70d6', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(46, 'palegoldenrod', '#eee8aa', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(47, 'palegreen', '#98fb98', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(48, 'peru', '#cd853f', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(49, 'purple', '#800080', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(50, 'red', '#ff0000', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(51, 'rosybrown', '#bc8f8f', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(52, 'saddlebrown', '#8b4513', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(53, 'salmon', '#fa8072', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(54, 'slategray', '#708090', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(55, 'steelblue', '#4682b4', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(56, 'teal', '#008080', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(57, 'tomato', '#ff6347', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(58, 'turquoise', '#40e0d0', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(59, 'violet', '#ee82ee', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(60, 'yellow', '#ffff00', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(61, '#f44336', '#f44336', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(62, '#e91e63', '#e91e63', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(63, '#9c27b0', '#9c27b0', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(64, '#673ab7', '#673ab7', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(65, '#3f51b5', '#3f51b5', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(66, '#2196f3', '#2196f3', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(67, '#03a9f4', '#03a9f4', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(68, '#00bcd4', '#00bcd4', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(69, '#009688', '#009688', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(70, '#4caf50', '#4caf50', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(71, '#74d108', '#74d108', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(72, '#cddc39', '#cddc39', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(73, '#ffeb3b', '#ffeb3b', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(74, '#ffc107', '#ffc107', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(75, '#ff9800', '#ff9800', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(76, '#ff5722', '#ff5722', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comunidades`
--

CREATE TABLE `comunidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comunidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `esPropia` tinyint(1) NOT NULL DEFAULT '0',
  `tipo_secretariado_id` bigint(20) UNSIGNED NOT NULL,
  `responsable` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion_postal` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cp` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pais_id` bigint(20) UNSIGNED NOT NULL,
  `provincia_id` bigint(20) UNSIGNED NOT NULL,
  `localidad_id` bigint(20) UNSIGNED NOT NULL,
  `email_solicitud` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_envio` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `web` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telefono1` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `telefono2` varchar(13) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tipo_comunicacion_preferida_id` bigint(20) UNSIGNED NOT NULL,
  `observaciones` text COLLATE utf8_unicode_ci NOT NULL,
  `esColaborador` tinyint(1) NOT NULL DEFAULT '1',
  `color` varchar(7) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#000000',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `comunidades`
--

INSERT INTO `comunidades` (`id`, `comunidad`, `esPropia`, `tipo_secretariado_id`, `responsable`, `direccion`, `direccion_postal`, `cp`, `pais_id`, `provincia_id`, `localidad_id`, `email_solicitud`, `email_envio`, `web`, `facebook`, `telefono1`, `telefono2`, `tipo_comunicacion_preferida_id`, `observaciones`, `esColaborador`, `color`, `activo`, `created_at`, `updated_at`) VALUES
(7, 'CURSILLOS DE CRISTIANDAD DIÓCESIS DE CANARIAS', 1, 1, 'Paulino Moreno', 'C./Profesor García Tello nº4', 'App correos nº844 (DP 35080)', '35001', 73, 1, 15, 'pedidosoracion@mcclaspalmas.com', 'enviosoracion@mcclaspalmas.com', '', '', '', '', 2, '', 1, '#006400', 1, '2015-12-11 19:17:54', '2015-12-11 19:44:58'),
(12, 'Medellín', 0, 1, '', 'c/. 57 nº 50-75', '', '', 52, 5, 37, '', '', '', '', '', '', 1, 'Email devuelto  mcc5@une.net.com ', 1, '#000000', 1, '2015-12-15 17:01:13', '2016-01-09 17:10:51'),
(13, 'ALCALÁ', 0, 1, '', '', 'Apartado de correos 285', '28805', 73, 23, 93, 'cursillosdealcala@yahoo.es', 'cursillosdealcala@yahoo.es', '', '', '', '', 2, 'Comunidad comprobada 01-2016', 1, '#000000', 1, '2015-12-15 22:38:07', '2016-01-10 09:24:59'),
(14, 'ALBACETE', 0, 1, '', 'Salamanca 10', '', '02001', 73, 15, 39, 'cursillosalbacete@gmail.com', 'cursillosalbacete@gmail.com', '', '', '', '', 2, '', 1, '#00fa9a', 1, '2015-12-15 22:40:05', '2015-12-15 22:40:05'),
(15, 'ALMERÍA', 0, 1, '', '', 'Apartado 128', '04080', 73, 16, 40, 'cursillosalmeria@gmail.com', 'cursillosalmeria@gmail.com', '', '', '', '', 2, '', 1, '#00fa9a', 1, '2015-12-15 22:41:50', '2015-12-15 22:41:50'),
(16, 'ASTORGA', 0, 1, '', 'C/.Del Carmen 2', '', '24700', 73, 28, 41, '', '', '', '', '', '', 1, '', 1, '#00ff00', 1, '2015-12-15 22:43:21', '2015-12-15 22:43:21'),
(17, 'AVILA', 0, 1, '', '', 'Apartado 152', '05080', 73, 18, 42, '', '', '', '', '', '', 1, '', 1, '#03a9f4', 1, '2015-12-15 22:45:29', '2015-12-15 22:45:29'),
(18, 'MÉRIDA-BADAJOZ', 0, 1, '', 'C/ Antº Masa Campos 11 bajo izq', '', '06005', 73, 19, 43, 'decoloresbadajoz@hotmail.com', 'decoloresbadajoz@hotmail.com', '', '', '', '', 2, '', 1, '#2196f3', 1, '2015-12-15 22:47:37', '2015-12-15 22:47:37'),
(19, 'BARCELONA', 0, 1, '', 'Pº Fabra y Pu8ig 260 2º ', '', '08016', 73, 20, 44, 'cursetsdecristiandat@yahoo.es', 'cursetsdecristiandat@yahoo.es', '', '', '', '', 2, '', 1, '#32cd32', 1, '2015-12-15 22:49:41', '2015-12-15 22:49:41'),
(20, 'BILBAO', 0, 1, '', 'Plaza Nueva 4 3º Edif Barria', '', '48005', 73, 60, 94, 'cursilloscbi@bizkaia.eus', 'cursilloscbi@bizkaia.eus', 'www.cursillosdecristiandad.org', '', '', '', 2, '', 1, '#32cd32', 1, '2015-12-15 22:54:46', '2016-01-13 15:14:38'),
(21, 'BURGOS', 0, 1, '', '', 'Apartado 345', '09080', 73, 6, 45, '', '', '', '', '', '', 1, '', 1, '#3cb371', 1, '2015-12-15 22:56:35', '2015-12-15 22:56:35'),
(22, 'CÁDIZ Y CEUTA', 0, 1, '', '', 'Apartado 672', '11080', 73, 7, 46, '', '', '', '', '', '', 1, '', 1, '#3f51b5', 1, '2015-12-15 22:57:45', '2015-12-15 22:57:45'),
(23, 'CALAHORRA Y LA CALZADA', 0, 1, '', 'c/ Obispo Fidel García 1', '', '26004', 73, 8, 47, 'mcclarioja@movistar.es', 'mcclarioja@movistar.es', '', '', '', '', 2, '', 1, '#32cd32', 1, '2015-12-15 22:59:34', '2015-12-15 22:59:34'),
(24, 'CARTAGENA-MURCIA', 0, 1, '', 'c/. Vinadel 9', 'Apartado 4608', '30004', 73, 9, 48, 'cursilloscristiandadmurcia@gmail.com', 'cursilloscristiandadmurcia@gmail.com', '', '', '', '', 2, '', 1, '#40e0d0', 1, '2015-12-15 23:02:04', '2015-12-15 23:02:04'),
(25, 'CIUDAD REAL', 0, 1, '', '', 'Apartado 555', '13080', 73, 10, 49, '', '', '', '', '', '', 1, '', 1, '#3f51b5', 1, '2015-12-15 23:03:00', '2015-12-15 23:03:00'),
(26, 'CORDOBA', 0, 1, '', 'C/.Cursillos s/n', '', '14012', 73, 11, 50, '', '', '', '', '', '', 1, '', 1, '#40e0d0', 1, '2015-12-15 23:04:11', '2015-12-15 23:04:11'),
(28, 'CUENCA', 0, 1, '', 'Callejón de los Artículos 1', '', '16001', 73, 13, 52, '', '', '', '', '', '', 1, '', 1, '#4b0082', 1, '2015-12-15 23:06:39', '2015-12-15 23:06:39'),
(29, 'GERONA', 0, 1, '', '', 'Apartado 683', '17080', 73, 22, 53, 'marionatorras1942@gmail.com', 'marionatorras1942@gmail.com', '', '', '', '', 2, '', 1, '#4caf50', 1, '2015-12-15 23:09:13', '2016-01-13 15:19:01'),
(30, 'GETAFE', 0, 1, '', '', 'Apartado 144', '28911', 73, 23, 95, '', '', '', '', '', '', 1, '', 1, '#40e0d0', 1, '2015-12-15 23:13:04', '2016-01-08 22:36:02'),
(31, 'GRANADA', 0, 1, '', '', 'Apartado 256', '18080', 73, 24, 55, 'mccgranada@hotmail.com', 'mccgranada@hotmail.com', '', '', '', '', 2, '', 1, '#4caf50', 1, '2015-12-15 23:15:44', '2015-12-15 23:15:44'),
(32, 'GUADIX-BAZA', 0, 1, '', 'c/. Santa María 4', '', '18500', 73, 24, 56, '', '', '', '', '', '', 1, '', 1, '#40e0d0', 1, '2015-12-15 23:18:38', '2015-12-15 23:18:38'),
(33, 'HUELVA', 0, 1, '', 'c/. Puerto 49 1º B', '', '21001', 73, 25, 57, 'cursilloshuelva@hotmail.es', 'cursilloshuelva@hotmail.es', '', '', '', '', 2, '', 1, '#5f9ea0', 1, '2015-12-15 23:20:20', '2015-12-15 23:20:20'),
(34, 'JACA', 0, 1, '', 'C/ Serrablo 76 1º M.Carmen Bergua', '', '22600', 73, 26, 58, 'cursillosjaca@yahoo.es', 'cursillosjaca@yahoo.es', '', '', '', '', 2, '', 1, '#66cdaa', 1, '2015-12-15 23:22:03', '2015-12-15 23:22:03'),
(35, 'JAÉN', 0, 1, '', 'c/. Maestro Bartolomé 5 ', '', '23007', 73, 27, 59, '', '', '', '', '', '', 1, '', 1, '#673ab7', 1, '2015-12-15 23:23:17', '2015-12-15 23:23:17'),
(36, 'JEREZ', 0, 1, '', 'C/. Moscatel 6 Edif ARIES', '', '11404', 73, 7, 60, '', '', '', '', '', '', 1, '', 1, '#32cd32', 1, '2015-12-16 08:19:06', '2015-12-16 08:19:06'),
(37, 'LEON', 0, 1, '', 'C/. Padre Isla 34 2º izq', '', '24002', 73, 28, 61, '', '', '', '', '', '', 1, '', 1, '#696969', 1, '2015-12-16 08:20:24', '2015-12-16 08:20:24'),
(38, 'LÉRIDA', 0, 1, '', 'c/. Blondell 11 2º', '', '25002', 73, 29, 62, '', '', '', '', '', '', 1, '', 1, '#708090', 1, '2015-12-16 08:21:35', '2015-12-16 08:21:35'),
(39, 'LUGO', 0, 1, '', 'c/. Cruz 3', '', '27001', 73, 30, 63, '', '', '', '', '', '', 1, '', 1, '#708090', 1, '2015-12-16 08:22:37', '2015-12-16 08:22:37'),
(40, 'MADRID', 0, 1, '', 'C/. General Yagüe 23', '', '28020', 73, 23, 64, 'secretariado@cursillosmadrid.org', 'secretariado@cursillosmadrid.org', '', '', '', '', 2, '', 1, '#74d108', 1, '2015-12-16 08:24:27', '2015-12-16 08:24:27'),
(41, 'MÁLAGA', 0, 1, '', 'c/. Santa María 29', '', '29015', 73, 31, 65, '', '', '', '', '', '', 1, '', 1, '#800000', 1, '2015-12-16 08:25:41', '2015-12-16 08:25:41'),
(42, 'MALLORCA', 0, 1, '', 'C/. Seminario 4 Casa Iglesia', '', '07001', 73, 32, 66, 'oficina@mccmallorca.org', 'oficina@mccmallorca.org', '', '', '', '', 2, '', 1, '#800080', 1, '2015-12-16 08:27:32', '2015-12-16 08:27:32'),
(43, 'ORENSE', 0, 1, '', '', 'Apartado 10', '32080', 73, 33, 67, '', '', '', '', '', '', 1, '', 1, '#808000', 1, '2015-12-16 08:28:48', '2015-12-16 08:28:48'),
(44, 'ORIHUELA-ALICANTE', 0, 1, '', 'Plaza de Colón 15', '', '03650', 73, 34, 68, 'jasororico@gmail.com', 'jasororico@gmail.com', '', '', '', '', 2, '', 1, '#8b008b', 1, '2015-12-16 08:32:40', '2015-12-16 08:32:40'),
(45, 'OSMA-SORIA', 0, 1, '', 'c/. San Juan 5  Casa Diocesana', '', '42003', 73, 35, 69, '', '', '', '', '', '', 1, '', 1, '#8b4513', 1, '2015-12-16 08:33:47', '2015-12-16 08:33:47'),
(47, 'PALENCIA', 0, 1, '', 'C/. Juan Balmaseda 9  1º D Sr. Ovidio', '', '34004', 73, 37, 71, '', '', '', '', '', '', 1, '', 1, '#8fbc8f', 1, '2015-12-16 08:36:21', '2015-12-16 08:36:21'),
(48, 'PAMPLONA-TUDELA', 0, 1, '', 'c/. San Agustín 3 bajo', '', '31001', 73, 38, 72, '', '', '', '', '', '', 1, '', 1, '#90ee90', 1, '2015-12-16 08:37:38', '2015-12-16 08:37:38'),
(49, 'SALAMANCA', 0, 1, '', 'c/. Rector Lucena 20-28 5º A', '', '37002', 73, 39, 73, '', '', '', '', '', '', 1, '', 1, '#90ee90', 1, '2015-12-16 08:39:23', '2015-12-16 08:39:23'),
(50, 'SAN SEBASTIÁN', 0, 1, '', 'c/ Zabaleta s/n - Parroq S. Ignacio (GROS)', '', '20002', 73, 40, 74, '', '', '', '', '', '', 1, '', 1, '#98fb98', 1, '2015-12-16 08:41:13', '2015-12-16 08:41:13'),
(51, 'SANTANDER', 0, 1, '', 'C/. Florida 3  Casa de la Iglesia', '', '39007', 73, 41, 75, '', '', '', '', '', '', 1, '', 1, '#9c27b0', 1, '2015-12-16 08:42:17', '2015-12-16 08:42:17'),
(52, 'SANTIAGO DE COMPOSTELA', 0, 1, '', 'Rúa J.M. Suárez Nuñez 6 Casa Ejerc  Campus Sur', '', '15705', 73, 42, 76, '', '', '', '', '', '', 1, '', 1, '#a52a2a', 1, '2015-12-16 08:44:16', '2015-12-16 08:44:16'),
(53, 'SEGORBE-CASTELLÓN', 0, 1, '', '', 'Apartado 209', '12080', 73, 43, 77, 'mccsegorbecastellon@gmail.com', 'mccsegorbecastellon@gmail.com', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-16 08:46:08', '2015-12-16 08:46:08'),
(54, 'SEGOVIA', 0, 1, '', 'C/. Seminario 4 Deleg Misiones', '', '40001', 73, 44, 78, 'cursilloscristiandadsg@gmail.com', 'cursilloscristiandadsg@gmail.com', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-16 08:48:20', '2015-12-16 08:48:20'),
(55, 'SEVILLA', 0, 1, '', 'c/. Segovias 2 ', '', '41004', 73, 45, 79, 'mccsvq@gmail.com', 'mccsvq@gmail.com', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-16 08:50:08', '2015-12-16 08:50:08'),
(56, 'SIGÚENZA-GUADALAJARA', 0, 1, '', 'C/. Salazaras 3', '', '19001', 73, 46, 80, 'decoloresguadalajara@gmail.com', 'decoloresguadalajara@gmail.com', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-16 08:51:45', '2015-12-16 08:51:45'),
(57, 'TARAZONA', 0, 1, '', 'Parroquia S Antº de Padua - Carret Valencia', '', '50300', 73, 47, 81, '', '', '', '', '', '', 1, '', 1, '#b0c4de', 1, '2015-12-16 08:53:33', '2015-12-16 08:53:33'),
(58, 'TENERIFE', 0, 1, '', 'Trasera Seminario D.-La Verdellada', '', '38207', 73, 48, 82, 'cursillostfe_secre@hotmail.com', 'cursillostfe_secre@hotmail.com', '', '', '', '', 2, '', 1, '#b0c4de', 1, '2015-12-16 08:55:25', '2015-12-16 08:55:25'),
(59, 'TERUEL Y ALBARRACÍN', 0, 1, '', '', 'Apartado 12', '44001', 73, 49, 83, 'mccteruel@hotmail.com', 'mccteruel@hotmail.com', '', '', '', '', 1, 'Email devuelto', 1, '#b0c4de', 1, '2015-12-16 08:56:50', '2016-01-09 16:18:11'),
(60, 'TOLEDO', 0, 1, '', '', 'Apartado 226', '45600', 73, 50, 84, 'info@cursillostoledo.org', 'info@cursillostoledo.org', '', '', '', '', 2, '', 1, '#b22222', 1, '2015-12-16 08:58:25', '2016-01-13 11:45:03'),
(61, 'TORTOSA', 0, 1, '', '', 'Apartado 189', '43500', 73, 51, 85, '', '', '', '', '', '', 1, '', 1, '#b8860b', 1, '2015-12-16 08:59:30', '2015-12-16 08:59:30'),
(62, 'TUY-VIGO', 0, 1, '', 'c/. Vázquez Varela 29 ', 'Apartado 1564', '36204', 73, 52, 86, '', '', '', '', '', '', 1, '', 1, '#ba55d3', 1, '2015-12-16 09:01:14', '2015-12-30 09:49:18'),
(63, 'VALENCIA', 0, 1, '', 'c/. Pablo Meléndez 13 - bajo', '', '46007', 73, 53, 88, '', '', '', '', '', '', 1, '', 1, '#ba55d3', 1, '2015-12-16 09:29:00', '2015-12-16 09:29:00'),
(64, 'VALLADOLID', 0, 1, '', 'C/.Simón Aranda 13 2º', '', '47002', 73, 54, 89, '', '', '', '', '', '', 1, '', 1, '#90ee90', 1, '2015-12-16 09:40:15', '2015-12-16 09:40:15'),
(65, 'VITORIA', 0, 1, '', 'c/. Portal de Castilla 34 2º', '', '01007', 73, 55, 90, '', '', '', '', '', '', 1, '', 1, '#cd5c5c', 1, '2015-12-16 09:41:39', '2015-12-16 09:41:39'),
(66, 'ZAMORA', 0, 1, '', 'Plaza del Seminario 2 Casa Iglesia', '', '49003', 73, 56, 91, '', '', '', '', '', '', 1, '', 1, '#98fb98', 1, '2015-12-16 09:42:57', '2015-12-16 09:42:57'),
(67, 'ZARAGOZA', 0, 1, '', 'Plaza Seo 6 Pta 3 Desp 306  Casa Iglesia', '', '50001', 73, 47, 92, 'mcczaragoza@terra.es', 'mcczaragoza@terra.es', '', '', '', '', 1, 'email devuelto', 1, '#ffff00', 1, '2015-12-16 09:44:47', '2016-01-09 16:10:03'),
(68, 'CORIA-CÁCERES', 0, 1, '', 'C/.General Esponda 14 Casa Iglesia', '', '10004', 73, 12, 96, '', '', '', '', '', '', 1, '', 1, '#4caf50', 1, '2015-12-16 11:12:39', '2015-12-16 11:12:39'),
(69, 'MONDOÑEDO-FERROL', 0, 1, '', '', '', '35000', 73, 30, 63, 'jfcarolo@hotmail.com', 'jfcarolo@hotmail.com', '', '', '', '', 2, '', 1, '#90ee90', 1, '2015-12-16 11:22:34', '2015-12-16 11:22:34'),
(70, 'PLASENCIA', 0, 1, '', '', '', '06400', 73, 55, 51, 'murillofuentes@gmail.com', 'murillofuentes@gmail.com', '', '', '', '', 2, '', 1, '#eee8aa', 1, '2015-12-16 11:27:16', '2015-12-16 11:27:16'),
(71, 'GED DIVINOPOLIS', 0, 3, '', 'Rua Maranhao 420 Sala 5', 'PO Box 317', '35500.029', 33, 61, 98, 'gedivinopolis@ig.com.br', 'gedivinopolis@ig.com.br', 'www.cursilhodivinopolis.com.br', '', '', '', 2, '', 1, '#000080', 1, '2015-12-16 22:26:17', '2015-12-18 16:13:54'),
(72, 'ITAJUBÁ', 0, 2, '', '', '', '', 33, 62, 100, 'carlos.mccitalav@gmail.com', 'carlos.mccitalav@gmail.com', '', '', '', '', 2, '', 1, '#0000cd', 1, '2015-12-16 22:28:00', '2015-12-16 22:28:00'),
(73, 'MARIANA', 0, 1, '', '', '', '', 33, 63, 101, 'gedmariana@yahoo.com.br', 'gedmariana@yahoo.com.br', '', '', '', '', 2, '', 1, '#0000ff', 1, '2015-12-16 22:29:28', '2015-12-16 22:29:28'),
(74, 'MARINGÁ', 0, 1, '', 'Basílica Nossa Senhora da Gloria', '', '87001.970', 33, 64, 102, 'alavancasmaringa@gmail.com', 'alavancasmaringa@gmail.com', 'www.cursilhomaringa.com.br', '', '', '', 2, '', 1, '#006400', 1, '2015-12-16 22:32:00', '2015-12-18 16:22:38'),
(75, 'OURINHOS', 0, 1, '', '', 'Caixa Postal 156', '19900.000', 33, 65, 103, 'mccalavancaourinhos@gmail.com', 'mccalavancaourinhos@gmail.com', '', '', '', '', 2, '', 1, '#008000', 1, '2015-12-16 22:33:52', '2015-12-18 16:25:07'),
(76, 'JALES', 0, 1, '', '', '', '', 33, 66, 104, 'cursilho.jales@gmail.com', 'cursilho.jales@gmail.com', '', '', '', '', 2, '', 1, '#000000', 1, '2015-12-16 22:35:01', '2015-12-16 22:35:01'),
(77, 'JUNDIAÍ', 0, 1, '', 'Rua Eng Roberto Mange 400 Anhangabaú', '', '13208.200', 33, 67, 105, 'cursilho@dj.org.br', 'cursilho@dj.org.br', '', '', '', '', 2, '', 1, '#000000', 1, '2015-12-16 22:36:55', '2015-12-18 16:18:33'),
(78, 'APUCARANA', 0, 1, '', 'Estrada do Rio Bom  km 1 CEFAS CP 10', 'Caixa Postal 10', '86800.970', 33, 68, 106, 'cur.apucarana@bol.com.br', 'cur.apucarana@bol.com.br', 'http://fredciappina.blogspot.com.es', '', '', '', 1, 'email devuelto', 1, '#008080', 1, '2015-12-16 22:39:11', '2016-01-09 16:48:42'),
(79, 'NOVA IGUAZÚ', 0, 1, '', 'Rua Adriano Hipólito 08 segundo andar Moquetá', '', '26285.330', 33, 80, 107, 'bandadecolores@supering.com.br', 'bandadecolores@supering.com.br', 'www.cursilho-ni.org.br', '', '', '', 1, 'email devuelto', 1, '#009688', 1, '2015-12-16 22:42:30', '2016-01-09 16:45:42'),
(81, 'FLORIANAPOLIS', 0, 1, '', '', '', '', 33, 71, 110, 'andremuller.ma@gmail.com', 'andremuller.ma@gmail.com', '', '', '', '', 2, '', 1, '#00fa9a', 1, '2015-12-16 22:46:59', '2015-12-16 22:46:59'),
(82, 'UMUARAMA', 0, 1, '', 'Av Pe. José Germano Jr. 4200', 'Caixa Postal 774', '87502.970', 33, 64, 112, 'cursilhos@diocesedeumuarama.org.br', 'nelson.delta@hotmail.com', 'www.cursilhosumuarama.org.br', '', '', '', 2, '', 1, '#00ff00', 1, '2015-12-16 22:50:16', '2015-12-18 16:34:35'),
(83, 'ARACATUBA', 0, 1, '', '', 'Caixa Postal 143', '16001.970', 33, 74, 113, 'alavanca.atamcc@gmail.com', 'alavanca.atamcc@gmail.com', 'http://mccaracatuba.wordpress.com', '', '', '', 2, '', 1, '#00ff00', 1, '2015-12-16 22:52:38', '2015-12-18 16:02:11'),
(84, 'CURITIBA', 0, 1, '', 'Rua Pe. Paulo Canelles 1000 ', '', '82720.350', 33, 75, 114, 'alavancas@cursilhocuritiba.com.br', 'alavancas@cursilhocuritiba.com.br', 'www.cursilhocuritiba.com', '', '', '', 1, 'email devuelto', 1, '#03a9f4', 1, '2015-12-16 22:54:48', '2016-01-09 16:42:17'),
(85, 'RIO DO SUL', 0, 1, '', 'Al. Aristiliano Ramos 275', '', '89160.000', 33, 76, 115, 'alavanca.riodosul@hotmail.com', 'alavanca.riodosul@hotmail.com', '', '', '', '', 2, '', 1, '#2196f3', 1, '2015-12-16 22:57:01', '2015-12-18 16:29:54'),
(86, 'SANTA MARÍA', 0, 1, '', '', 'Caixa Postal 7010', '97091.970', 33, 77, 116, 'alavancas.mccsm@gmail.com', 'alavancas.mccsm@gmail.com', '', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-16 22:58:29', '2015-12-18 16:30:55'),
(87, 'ITUMBIARA', 0, 1, '', 'Rua Cachoeira Dourada 234  Santa Inés', '', '75526.060', 33, 78, 117, 'contato@mccitumbiara.com.br', 'rubianeoliveira@hotmail.com', 'http://mccitumbiara.com.br', '', '', '', 1, 'Email devuelto', 1, '#3f51b5', 1, '2015-12-16 23:02:02', '2016-01-09 16:44:16'),
(88, 'MACEIÓ', 0, 3, '', 'Rua Prof Angelo Neto 279 Farol', '', '57051.530', 33, 79, 118, 'alavancas@mccmaceio.org.br', 'gedmaceio@gmail.com', '', '', '', '', 2, 'Email devuelto', 1, '#4682b4', 1, '2015-12-16 23:04:13', '2016-01-09 16:11:36'),
(89, 'RIO DE JANEIRO', 0, 1, '', 'Rua Benjamín Constant 23 pesos.304 Gloria', '', '', 33, 80, 119, 'alavanca@cursilhorio.org.br', 'cursilhorio@arquidiocese.org.br', 'http://cursilhorio.org.br', '', '', '', 2, '', 1, '#32cd32', 1, '2015-12-16 23:06:57', '2015-12-16 23:06:57'),
(90, 'VITORIA', 0, 3, '', 'Av Min Salgado Filho 1122 Soteco', '', '29106.010', 33, 81, 143, 'alavancagedvitoria@gmail.com', 'alavancagedvitoria@gmail.com', '', '', '', '', 2, '', 1, '#66cdaa', 1, '2015-12-17 08:45:27', '2015-12-18 16:37:40'),
(91, 'ARACAJU SERGIPE', 0, 1, '', 'Rua Preopriá 222', '', '49010.020', 33, 83, 121, 'mccaracajuescola@gmail.com', 'mccaracajuescola@gmail.com', 'www.mccaracaju.com.br', '', '', '', 2, '', 1, '#673ab7', 1, '2015-12-17 08:48:34', '2015-12-18 15:57:02'),
(92, 'BRASILIA', 0, 1, '', '', 'Caixa Postal 07103', '70359.970', 33, 84, 122, 'mccbrasilia@gmail.com', 'mccbrasilia@gmail.com', '', '', '', '', 2, '', 1, '#696969', 1, '2015-12-17 08:50:14', '2015-12-18 16:04:02'),
(93, 'ITAPETININGA', 0, 1, '', 'Rua Quintino Bocaiúva 289 centro', '', '18200.670', 33, 85, 123, 'alineaugusta1611@gmail.com', 'alineaugusta1611@gmail.com', '', '', '', '', 2, '', 1, '#74d108', 1, '2015-12-17 08:52:34', '2015-12-18 16:15:22'),
(94, 'BRAGANCA PAULISTA', 0, 1, '', '', 'Caixa Postal 145', '12914.970', 33, 86, 124, 'alavancabp@hotmail.com', 'alavancabp@hotmail.com', '', '', '', '', 2, '', 1, '#74d108', 1, '2015-12-17 08:54:26', '2015-12-18 16:02:55'),
(95, 'CAMPO MOURAO', 0, 1, '', 'Rua Araruna 227', '', '87301.120', 33, 87, 125, 'alavancacm@gmail.com', 'irineuhanel@hotmail.com', '', '', '', '', 2, '', 1, '#800000', 1, '2015-12-17 08:56:30', '2015-12-18 16:05:09'),
(96, 'JATAÍ', 0, 1, '', '', 'Caixa Postal 55', '75800.061', 33, 88, 127, 'iga@uol.com.br', 'iga@uol.com.br', '', '', '', '', 2, '', 1, '#808000', 1, '2015-12-17 08:57:56', '2015-12-18 16:17:45'),
(97, 'PETROPOLIS', 0, 1, '', '', 'Caixa Postal 90489', '25621.970', 33, 89, 128, 'mccpetropolisrj@bol.com.br', 'mccpetropolisrj@bol.com.br', '', '', '', '', 1, 'email devuelto', 1, '#808000', 1, '2015-12-17 08:59:47', '2016-01-09 16:31:44'),
(98, 'URUGUAIANIA', 0, 1, '', '', 'Caixa Postal 186', '97510.470', 33, 90, 129, 'ged.mcc.uruguaiania@gmail.com', 'ged.mcc.uruguaiania@gmail.com', 'http://mccsetoruruguaiania.blospot.com.es', '', '', '', 1, 'Email devuelto', 1, '#90ee90', 1, '2015-12-17 09:02:17', '2016-01-09 16:15:31'),
(99, 'VACARIA', 0, 1, '', 'Rua Ramiro Barcelos 800 sala 203', '', '95200.000', 33, 91, 130, 'alavancasvacaria@bol.com.br', 'alavancasvacaria@bol.com.br', '', '', '', '', 2, '', 1, '#808000', 1, '2015-12-17 09:03:49', '2015-12-18 16:36:53'),
(100, 'PARANAVAÍ', 0, 1, '', '', 'Caixa Postal 491', '87700.970', 33, 64, 131, 'mcc_paranavai@hotmail.com', 'mcc_paranavai@hotmail.com', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-17 09:05:45', '2015-12-18 16:26:44'),
(101, 'SAO JOSÉ DO RIO PRETO', 0, 1, '', 'Rua Raul Silva 2239', '', '15090.260', 33, 93, 132, 'pauloborges8@terra.com.br', 'pauloborges8@terra.com.br', '', '', '', '', 2, '', 1, '#b0c4de', 1, '2015-12-17 09:07:29', '2015-12-18 16:31:46'),
(102, 'LEOPOLDINA', 0, 1, '', 'Rua Dr Clovis Salgado G 113 B Sao Cristovao', '', '36700.000', 33, 94, 133, 'mccsetoruba@yahoo.com.br', 'mccsetoruba@yahoo.com.br', '', '', '', '', 2, '', 1, '#9c27b0', 1, '2015-12-17 09:09:37', '2015-12-18 16:19:29'),
(103, 'PELOTAS', 0, 3, '', 'Av Dom Joaquim 1568 Tres Vendas', '', '', 33, 95, 134, 'marize.rovere@gmail.com', 'marize.rovere@gmail.com', 'www.mccpelotas.org', '', '', '', 2, '', 1, '#696969', 1, '2015-12-17 09:11:24', '2015-12-17 09:11:24'),
(104, 'CUIABÁ', 0, 1, '', 'Rua 13 de Junhp 786', '', '78020.901', 33, 96, 135, 'cursilhocuiaba@gmail.com', 'cursilhocuiaba@gmail.com', '', '', '', '', 2, '', 1, '#8b008b', 1, '2015-12-17 09:13:10', '2015-12-18 16:06:51'),
(105, 'SOROCABA', 0, 1, '', 'Av Eugenio Salerno 60  fundos-centro', '', '18035.430', 33, 97, 136, 'mcc.sorocaba@ig.com.br', 'mcc.sorocaba@ig.com.br', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-17 09:14:40', '2015-12-18 16:32:33'),
(106, 'TAUBATÉ', 0, 1, '', '', 'Caixa Postal 204', '12010.100', 33, 98, 137, 'arteflortaubate@gmail.com', 'arteflortaubate@gmail.com', '', '', '', '', 2, '', 1, '#ffc107', 1, '2015-12-17 09:23:06', '2015-12-18 16:33:21'),
(107, 'JACAREZHINO', 0, 1, '', '', 'Caixa Postal 205', '86400.000', 33, 64, 138, 'cursilhojacarezinho@hotmail.com', 'cursilhojacarezinho@hotmail.com', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-17 09:24:39', '2015-12-18 16:16:46'),
(108, 'PARANATINGA', 0, 1, '', 'Rua Fox Iguazu 74  B. Vista Alegre', '', '78870.000', 33, 100, 139, 'yedasnely@hotmail.com', 'yedasnely@hotmail.com', '', '', '', '', 1, 'email devuelto', 1, '#add8e6', 1, '2015-12-17 09:26:31', '2016-01-09 17:37:05'),
(109, 'ANÁPOLIS GOIAS', 0, 1, '', '', 'Caixa Postal 638', '75001.901', 33, 101, 140, 'alavanca@cursilhoanapolis.com.br', 'alavanca@cursilhoanapolis.com.br', 'www.cursilhoanapolis.com.br', '', '', '', 2, '', 1, '#eee8aa', 1, '2015-12-17 09:28:27', '2015-12-18 15:55:07'),
(110, 'CAXIAS DO SUL', 0, 1, '', '', 'Caixa Postal 380', '95001.970', 33, 70, 144, 'mcc@mccaxiasrs.com.br', 'canutodalcin@bol.com.br', 'mccaxiasrs.com.br', '', '', '', 1, 'email devuelto', 1, '#74d108', 1, '2015-12-17 10:03:15', '2016-01-09 16:50:45'),
(111, 'TEGUCIGALPA', 0, 1, '', 'Parroquia San Martín Porres Blvd.Suyapa', 'Apartado Postal 851', '', 102, 102, 145, 'jluisboba@yahoo.com.mx', 'jluisboba@yahoo.com.mx', 'http://www.cursillostegucigalpa.com', '', '', '', 2, 'secretariado@cursillostegucigalpa.com ', 1, '#fa8072', 1, '2015-12-17 10:56:29', '2016-01-13 15:22:34'),
(112, 'QUITO', 0, 1, '', 'C/. Bogotá - EE UU (Miraflores)', '', '', 66, 103, 146, 'vocaliapiedad_quito@yahoo.com', 'vocaliapiedad_quito@yahoo.com', 'cursillosquito.com', '', '', '', 2, '', 1, '#ff0000', 1, '2015-12-17 11:00:00', '2015-12-17 11:00:00'),
(113, 'MEDELLÍN', 0, 1, '', 'C/. 57  nº 50-75', '', '', 52, 5, 37, 'mcc5@une.net.com', 'mcc5@une.net.com', '', '', '', '', 2, '', 1, '#fa8072', 1, '2015-12-17 11:02:12', '2015-12-17 11:02:12'),
(114, 'SAN SALVADOR', 0, 1, '', '79 Av Sur nº 200  Colonia Escalón', '', '', 68, 106, 148, 'secretariadonacional.elsalvador@gmail.com', 'secretariadonacional.elsalvador@gmail.com', '', '', '', '', 2, '', 1, '#ff00ff', 1, '2015-12-17 11:04:34', '2015-12-17 11:04:34'),
(115, 'PONCE', 0, 1, '', '472 Ave Tito Castro  suite 202  Ed Marvesa', '', '00716', 178, 107, 149, 'mccdiocesisponce@gmail.com', 'mccdiocesisponce@gmail.com', '', '', '', '', 2, '', 1, '#ff00ff', 1, '2015-12-17 11:07:07', '2015-12-17 11:07:07'),
(116, 'TOKYO', 0, 1, '', '4-2-37 Roppongi  Minato-ku', '', '106', 114, 108, 150, '', '', '', '', '', '', 1, '', 1, '#ff00ff', 1, '2015-12-17 11:43:00', '2015-12-17 11:43:00'),
(117, 'CURSILLO TITKÁRSÁG', 0, 1, '', '4000 Sf. Gheorge  Str Vittorului 2/A/4', '', '', 183, 109, 151, '', '', '', '', '', '', 1, '', 1, '#ffff00', 1, '2015-12-17 11:45:34', '2015-12-17 11:45:34'),
(118, 'SANTIAGO ANG', 0, 1, '', 'Victoria Subercaseaux 41 Of 301', '', '', 46, 113, 154, 'comunicaciones@iach.cl', 'comunicaciones@iach.cl', '', '', '', '', 2, '', 1, '#cd5c5c', 1, '2015-12-17 13:20:14', '2015-12-17 13:20:14'),
(119, 'SANTIAGO', 0, 1, '', '', '', '', 46, 113, 154, 'mcczonaorientepalanca@gmail.com', 'mcczonaorientepalanca@gmail.com', '', '', '', '', 2, 'email devuelto. No tenemos dirección postal', 0, '#cddc39', 0, '2015-12-17 13:23:28', '2016-01-09 17:05:29'),
(120, 'LOS ANGELES', 0, 1, '', 'Bulnes 896 Los Ángeles 8ª', '', '', 46, 114, 155, 'piedadmcclosangeleschile@gmail.com', 'piedadmcclosangeleschile@gmail.com', '', '', '', '', 2, '', 1, '#cd853f', 1, '2015-12-17 13:25:20', '2015-12-17 13:25:20'),
(121, 'CHITRÉ', 0, 1, '', '', 'Apartado 250', '', 170, 115, 156, 'amanais21@gmail.com', 'amanais21@gmail.com', '', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-17 13:27:14', '2015-12-17 13:27:14'),
(122, 'PANAMÁ', 0, 1, '', '', 'Apartado Postal 816-3555', '', 170, 116, 157, 'sede@mccarqpma.org', 'sede@mccarqpma.org', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-17 13:28:59', '2015-12-17 13:28:59'),
(123, 'AREQUIPA', 0, 1, '', 'San Agustín 205  Cercado', '', '', 173, 117, 158, 'mccarequipa@gmail.com', 'gonzalomelino@yahoo.es', '', '', '', '', 2, '', 1, '#a52a2a', 1, '2015-12-17 13:30:27', '2015-12-17 13:30:27'),
(124, 'ICA', 0, 1, '', '', '', '', 173, 118, 159, 'mcchincha@hotmail.com', 'mcchincha@hotmail.com', '', '', '', '', 2, 'Email devuelto. No tenemos dirección', 0, '#000000', 0, '2015-12-17 13:32:27', '2016-01-09 17:21:10'),
(125, 'LIMA', 0, 1, '', 'Cayetano Heredia 815 ', '', '11', 173, 119, 160, 'cursilloslima@infonegocio.net.pe', 'cursilloslima@infonegocio.net.pe', '', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-17 13:33:55', '2015-12-17 13:33:55'),
(126, 'LA VEGA', 0, 1, '', '', 'Apartado 126', '', 65, 121, 164, 'mccdiocesisdelavega@hotmail.com', 'mariamargaritamota@gmail.com', '', '', '', '', 2, '', 1, '#b0c4de', 1, '2015-12-17 13:35:27', '2015-12-17 13:35:27'),
(127, 'MERCEDES', 0, 1, '', '25 DE mAYO 412', '', '70100', 229, 122, 165, 'susanaguthux@adinet.com.uy', 'susanaguthux@adinet.com.uy', '', '', '', '', 2, '', 1, '#b0c4de', 1, '2015-12-17 13:36:56', '2015-12-17 13:36:56'),
(128, 'MONTEVIDEO', 0, 1, '', '', '', '', 229, 123, 166, 'cursillomontevideo@gmail.com', 'cursillomontevideo@gmail.com', '', '', '', '', 2, '', 1, '#800080', 1, '2015-12-17 13:37:59', '2015-12-17 13:37:59'),
(130, 'SALTO', 0, 1, '', '', '', '', 229, 124, 167, 'mccdiocesisdesalto@gmail.com', 'mccdiocesisdesalto@gmail.com', '', '', '', '', 2, 'Email devuelto. No tenemos dirección postal', 0, '#ba55d3', 0, '2015-12-17 13:39:13', '2016-01-09 16:13:03'),
(131, 'SANTO DOMINGO', 0, 1, '', 'Av Rómulo Betancourt, casi esq Nuñez', 'apartado 2459', '', 65, 125, 168, 'precursillo@mcc.org.do', 'inf@mcc.org.do', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-17 13:41:39', '2015-12-17 13:41:39'),
(132, 'SAN FRANCISCO DE MACORÍS', 0, 1, '', 'Av Rómulo Betancourt 1700 Casa S Pablo', 'Apartado de Correos 58', '', 65, 125, 169, 'secretariado@mcc.org.do', 'secretariado@mcc.org.do', '', '', '', '', 2, '', 1, '#ee82ee', 1, '2015-12-17 13:44:07', '2015-12-17 13:44:07'),
(134, 'VALPARAÍSO', 0, 1, '', 'Casilla nº 2', '', '', 46, 111, 172, 'lupitadecolores@hotmail.com', 'lupitadecolores@hotmail.com', '', '', '', '', 2, '', 1, '#ff0000', 1, '2015-12-17 15:33:38', '2015-12-17 15:33:38'),
(135, 'SANTIAGO', 0, 1, '', 'C/. 30 de Marzo nº 1', '', '', 65, 120, 163, '', '', '', '', '', '', 1, '', 1, '#d2691e', 1, '2015-12-17 15:34:50', '2015-12-17 15:34:50'),
(136, 'BATHURST', 0, 1, '', '', '', '', 16, 128, 173, 'mullaney28@bigpond.com', 'mullaney28@bigpond.com', '', '', '', '', 2, '', 1, '#98fb98', 1, '2015-12-17 17:06:39', '2015-12-17 17:06:39'),
(137, 'AUST. CATHOLIC CURSILLO M.', 0, 1, '', 'Camdem NSW 2570', 'P.O. Box 777', '', 16, 127, 174, 'Mauricio.Merino@isispc.com.au', 'Mauricio.Merino@isispc.com.au', 'www.cursillo.asn.au', '', '', '', 2, '', 1, '#d2691e', 1, '2015-12-17 17:08:52', '2015-12-17 17:08:52'),
(138, 'KENTVILLE', 0, 1, '', 'St Joseph´s Church', 'P.O. Box 486', '', 42, 129, 175, 'vcursillo@gmail.com', 'vcursillo@gmail.com', '', '', '', '', 2, '', 1, '#696969', 1, '2015-12-17 17:11:00', '2015-12-17 17:11:00'),
(139, 'BRITISH COLUMBIA', 0, 1, '', '900 Vancouver Street', '', '', 42, 130, 176, 'cursillo@shaw.ca', 'cursillo@shaw.ca', 'www.CursilloBC.com', '', '', '', 2, '', 1, '#74d108', 1, '2015-12-17 17:12:47', '2015-12-17 17:12:47'),
(142, 'VANCOUVER', 0, 1, '', '315 Walker Street  O L Fátima', '', '', 42, 131, 177, 'cursillo@shaw.ca', 'cursillo@shaw.ca', 'http://decolores.a', '', '', '', 2, '', 1, '#ba55d3', 1, '2015-12-17 18:16:11', '2015-12-17 18:16:11'),
(143, 'JEJU', 0, 1, '', '', 'P O Box 50', '690-809', 58, 132, 180, 'jejucursillo@hanmail.net', '', '', '', '', '', 2, '', 1, '#708090', 1, '2015-12-17 18:18:47', '2015-12-17 18:18:47'),
(144, 'TAEGU', 0, 1, '', '225-1 NamSan 3 dong', '', '700-804', 58, 132, 180, '', '', '', '', '', '', 1, '', 1, '#b22222', 1, '2015-12-17 18:21:31', '2015-12-17 18:21:31'),
(145, 'SEOUL', 0, 1, '', '97-1 Hapjung-dong.Mapo-ku', '', '121-883', 58, 134, 182, '', '', '', '', '', '', 1, '', 1, '#74d108', 1, '2015-12-17 18:24:02', '2016-01-08 22:36:44'),
(146, 'BRNO', 0, 1, '', 'Mickova 55  Manzelé Sankovi', '', 'CA 614', 45, 135, 178, 'samkovah@iol.cz', 'samkovah@iol.cz', '', '', '', '', 1, 'email devuelto', 1, '#696969', 1, '2015-12-17 18:27:04', '2016-01-09 17:01:39'),
(147, 'KEMPNER', 0, 1, '', '11723 E. FM 580  Bolli Hopkins', '', '76539', 75, 136, 183, '', '', '', '', '', '', 1, '', 1, '#40e0d0', 1, '2015-12-17 20:24:18', '2016-01-08 22:37:22'),
(148, 'NAPLES', 0, 1, '', '1049 Grand Isle Drive  John Mcgrory', '', '34108', 75, 137, 196, '', '', '', '', '', '', 1, '', 1, '#483d8b', 1, '2015-12-17 20:25:39', '2015-12-17 20:25:39'),
(149, 'AUSTIN', 0, 1, '', '2805 Tobbs Run  Peggy Ryder', '', '78703', 75, 136, 185, 'sgyldenege@charter.net', 'sgyldenege@charter.net', 'www.episcopalcursillotexas.org', '', '', '', 2, '', 1, '#483d8b', 1, '2015-12-17 20:27:38', '2015-12-17 20:27:38'),
(150, 'HAWESVILLE', 0, 1, '', '1585 st Rt 2181  Denis&Martha ', '', '42348', 75, 139, 186, 'palanca@cursillo-owenboro.org', 'palanca@cursillo-owenboro.org', '', '', '', '', 1, 'email devuelto', 1, '#a52a2a', 1, '2015-12-17 20:29:49', '2016-01-09 17:17:01'),
(151, 'NEW YORK', 0, 1, '', '275 west 230 Street Bronx', '', '10463', 75, 140, 187, 'mccny275@gmail.com', 'glozano25@yahoo.com', '', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-17 20:31:51', '2015-12-18 17:30:30'),
(152, 'SAN DIEGO', 0, 1, '', '938 18 th  St', '', '92154', 75, 141, 188, 'cursillossd@cox.net', 'mlmontemayor@gmail.com', '', '', '', '', 1, 'email devuelto', 1, '#add8e6', 1, '2015-12-17 20:33:26', '2016-01-09 17:44:58'),
(153, 'OKHALOMA', 0, 1, '', '', '', '', 75, 142, 189, 'palancaruth@outlook.com', 'palancaruth@outlook.com', 'episcopalchurch.org', '', '', '', 2, '', 1, '#a52a2a', 1, '2015-12-17 20:35:25', '2015-12-17 20:35:25'),
(154, 'COLORADO SPRINGS', 0, 1, '', '', 'P O Box 25655', '80936', 75, 143, 190, 'mjbjquier@yahoo.es', 'mjbjquier@yahoo.es', '', '', '', '', 1, 'email devuelto', 1, '#cddc39', 1, '2015-12-17 20:36:55', '2016-01-09 17:15:53'),
(155, 'LITTLE ROCK', 0, 1, '', '2500 North Tyles Street', 'P O Box 7565', '', 75, 144, 191, 'littlerockarkansascursillo@gmail.com', 'littlerockarkansascursillo@gmail.com', '', '', '', '', 2, '', 1, '#cd853f', 1, '2015-12-17 20:38:42', '2015-12-17 20:38:42'),
(156, 'MANCHESTER NEW HAMPSHIRE', 0, 1, '', '', '', '', 75, 145, 192, 'palanca@nhcursillo.org', 'palanca@nhcursillo.org', '', '', '', '', 2, '', 1, '#eee8aa', 1, '2015-12-17 20:40:04', '2015-12-17 20:40:04'),
(157, 'PHOENIX', 0, 1, '', '2239 N. Shady Glen Ave', '', '85023', 75, 147, 194, 'palancadecolores@gmail.com', 'palancadecolores@gmail.com', '', '', '', '', 2, '', 1, '#708090', 1, '2015-12-17 20:44:03', '2015-12-17 20:44:03'),
(158, 'OAKLAND', 0, 1, '', '', '', '', 75, 146, 195, 'palanca_oakland@hotmail.com', '', '', '', '', '', 2, '', 1, '#0000cd', 1, '2015-12-17 20:45:16', '2015-12-17 20:45:16'),
(159, 'MIAMI', 0, 1, '', '16250 s.w. 112 th Avenue', '', '33157', 75, 137, 196, 'cursilloscristiandadmiami@gmail.com', 'cursillopalancas@aol.com', 'http://cursillomiami.org', '', '', '', 2, '', 1, '#d3d3d3', 1, '2015-12-17 20:47:44', '2015-12-17 20:47:44'),
(160, 'LOS ANGELES', 0, 1, '', '1105 Bluff rd. Montebello ', '', '90640', 75, 146, 198, 'lacapalanca@gmail.com', 'lacapalanca@gmail.com', 'www.cursillola.org', '', '', '', 2, '', 1, '#b8860b', 1, '2015-12-17 20:52:36', '2015-12-17 20:52:36'),
(161, 'MONTERREY', 0, 1, '', '', 'Apartado Postal 2732', '64000', 146, 150, 199, 'palancas@mccmonterrey.org', 'palancas@mccmonterrey.org', 'www.monterrey.org', '', '', '', 2, '', 1, '#dc143c', 1, '2015-12-17 21:15:39', '2015-12-17 21:15:39'),
(162, 'TAMPICO', 0, 1, '', 'Privada Hidalgo 111  La herradura', '', '', 146, 151, 200, 'lupita_pintor@hotmail.com', 'grillito971@hotmail.com', '', '', '', '', 2, '', 1, '#a52a2a', 1, '2015-12-17 21:17:21', '2015-12-17 21:17:21'),
(163, 'DURANGO', 0, 1, '', '', '', '', 146, 154, 202, 'cursillosdgo@hotmail.com', '', '', '', '', '', 2, '', 1, '#40e0d0', 1, '2015-12-17 21:18:18', '2015-12-17 21:18:18'),
(164, 'ZAMORA', 0, 1, '', 'Cázarez 151 ote. ', '', '59260', 146, 155, 203, 'servicio@dacza-international.com', 'servicio@dacza-international.com', 'http://mcczamora.jimdo.com', '', '', '', 2, '', 1, '#708090', 1, '2015-12-17 21:20:33', '2015-12-17 21:20:33'),
(165, 'SAN JUAN DE LOS LAGOS', 0, 1, '', '', '', '', 146, 156, 204, 'marthayarturo1990@hotmail.com', 'marthayarturo1990@hotmail.com', '', '', '', '', 2, '', 1, '#ff6347', 1, '2015-12-17 21:22:00', '2015-12-17 21:22:00'),
(166, 'MÉRIDA', 0, 1, '', '', '', '', 146, 157, 205, 'mcc.merida@hotmail.com', 'mcc.merida@hotmail.com', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-17 21:23:06', '2015-12-17 21:23:06'),
(167, 'TOLUCA', 0, 1, '', '', 'Apartado Postal 2-53', '50000', 146, 158, 206, 'mcctolmex@hotmail.com', 'mcctolmex@hotmail.com', '', '', '', '', 2, '', 1, '#800080', 1, '2015-12-17 21:24:42', '2015-12-17 21:24:42'),
(168, 'TULACINGO', 0, 1, '', '', '', '', 146, 159, 207, 'acappoh@hotmail.com', 'acappoh@hotmail.com', '', '', '', '', 2, 'Email devuelto. No tenemos dirección postal', 0, '#daa520', 0, '2015-12-17 21:25:57', '2016-01-09 16:14:22'),
(169, 'NUEVO CASAS GRANDES', 0, 1, '', 'Aquiles Serdán 205', '', '31700', 146, 160, 208, 'fss_09@hotmail.com', 'fss_09@hotmail.com', '', '', '', '', 2, '', 1, '#d3d3d3', 1, '2015-12-17 21:27:29', '2015-12-17 21:27:29'),
(170, 'CIUDAD ALTAMIRANO', 0, 1, '', '', '', '', 146, 161, 209, 'mcc.smob.luvisi@gmail.com', 'mcc.smob.luvisi@gmail.com', '', '', '', '', 2, 'email devuelto. No tenemos dirección postal', 0, '#ff4500', 0, '2015-12-17 21:28:35', '2016-01-09 17:29:14'),
(171, 'XALAPA', 0, 1, '', 'Azcarate 35 centro', '', '01000', 146, 162, 210, 'clarissa1582@hotmail.com', 'clarissa1582@hotmail.com', '', '', '', '', 2, '', 1, '#9c27b0', 1, '2015-12-17 21:30:04', '2015-12-17 21:30:04'),
(172, 'SALTILLO', 0, 1, '', 'Guerrero 648 Zona Centro', '', '25000', 146, 163, 211, 'Niko.mtz@hotmail.com', 'decoloressaltillo@gmail.com', 'http://decoloressaltillo.blogspot.com.es/', '', '', '', 2, '', 1, '#d3d3d3', 1, '2015-12-17 21:32:34', '2015-12-17 21:32:34'),
(173, 'PUEBLA', 0, 1, '', '', '', '', 146, 164, 212, 'cursillospuebla@prodigymovil.com', 'cursillospuebla@prodigymovil.com', '', '', '', '', 2, '', 1, '#74d108', 1, '2015-12-17 21:33:38', '2015-12-17 21:33:38'),
(174, 'NOGALES', 0, 1, '', '', '', '', 146, 165, 213, 'cursillosdenogales@hotmail.com', 'cursillosdenogales@hotmail.com', '', '', '', '', 2, 'Email devuelto. No tenemos dirección postal', 0, '#ee82ee', 0, '2015-12-17 21:34:43', '2016-01-09 17:31:16'),
(175, 'PURÉPERO', 0, 1, '', '', 'Apartado Postal 24', '58760', 146, 155, 214, 'cursillistascentropurepero@hotmail.com', 'cursillistascentropurepero@hotmail.com', '', '', '', '', 2, '', 1, '#a52a2a', 1, '2015-12-17 21:36:08', '2015-12-17 21:36:08'),
(176, '5 MANANTIALES', 0, 1, '', '', '', '', 146, 167, 215, 'mcc5manantiales@hotmail.com', 'mcc5manantiales@hotmail.com', '', '', '', '', 2, 'email devuelto. No tenemos dirección postal', 0, '#ff4500', 0, '2015-12-17 21:37:13', '2016-01-09 16:51:46'),
(177, 'LEÓN', 0, 1, '', '', '', '', 146, 153, 216, 'olverita72@hotmail.com', 'mcc_leon@hotmail.com', '', '', '', '', 2, '', 1, '#d3d3d3', 1, '2015-12-17 21:38:40', '2015-12-17 21:38:40'),
(178, 'GUADALAJARA', 0, 1, '', 'Av. Tonantzin 1224 esq Crepúsculo', '', '45040', 146, 168, 217, 'mccgdlpalancainter@hotmail.com', 'mccgdlpalancainter@hotmail.com', '', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-17 21:40:39', '2015-12-17 21:40:39'),
(179, 'PORTO', 0, 1, '', 'R. Arcediano Van Zeller 50  Semin Vilar', '', '4050-621', 177, 169, 218, 'secretariado@mccporto.org', 'secretariado@mccporto.org', 'http://mccporto.org', '', '', '', 2, '', 1, '#ff8c00', 1, '2015-12-18 07:12:00', '2015-12-18 07:12:00'),
(180, 'ANGRA DO HEROISMO', 0, 1, '', '', 'Apartado 217', '9700', 177, 170, 219, 'mccangra.intendencia@gmail.com', 'mccangra.intendencia@gmail.com', '', '', '', '', 2, '', 1, '#4682b4', 1, '2015-12-18 07:13:19', '2015-12-18 07:13:19'),
(181, 'PONTA DELGADA-SAN MIGUEL', 0, 1, '', '', 'Apartado 116', '', 177, 170, 220, 'mccsmiguel@gmail.com', 'mccsmiguel@gmail.com', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 07:15:16', '2015-12-18 07:15:16'),
(182, 'FUNCHAL', 0, 1, '', 'Rua dos Ferreiros 105 Igreja Colégio', '', '9000.082', 177, 171, 221, 'dmccfunchal@gmail.com', 'dmccfunchal@gmail.com', '', '', '', '', 2, '', 1, '#daa520', 1, '2015-12-18 07:17:34', '2015-12-18 07:17:34'),
(183, 'AVEIRO', 0, 1, '', 'Rua José Estevas 50', '', '3800.201', 177, 172, 222, 'menamaral@gmail.com', 'menamaral@gmail.com', '', '', '', '', 2, '', 1, '#708090', 1, '2015-12-18 07:18:53', '2015-12-18 07:18:53'),
(184, 'VIANA DO CASTELO', 0, 1, '', '', '', '', 177, 173, 223, 'mccviana@gmail.com', 'mccviana@gmail.com', '', '', '', '', 2, '', 1, '#98fb98', 1, '2015-12-18 07:19:56', '2015-12-18 07:19:56'),
(185, 'COIMBRA', 0, 1, '', 'R. Padre Estevao Cabral 120 5º A', '', '3000.316', 177, 174, 224, 'amelia.jegundo@gmail.com', 'amelia.jegundo@gmail.com', '', '', '', '', 2, '', 1, '#ffa07a', 1, '2015-12-18 07:21:31', '2015-12-18 07:21:31'),
(186, 'BRAGANZA MIRANDA', 0, 1, '', '', '', '', 177, 175, 225, 'teresavila44@gmail.com', '', '', '', '', '', 2, '', 1, '#4682b4', 1, '2015-12-18 07:22:46', '2015-12-18 07:22:46'),
(187, 'VISEU', 0, 1, '', 'R.D. Antonio Monteiro nº 2', '', '3500.040', 177, 176, 226, 'mccviseu@gmail.com', 'mccviseu@gmail.com', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 07:24:30', '2015-12-18 07:24:30'),
(188, 'BRAGA', 0, 1, '', 'Rua do Alcalde 9', '', '4700.024', 177, 177, 227, 'raulcarvalhorc@gmail.com', 'raulcarvalhorc@gmail.com', 'www.maisalembraga.com', '', '', '', 2, '', 1, '#00bcd4', 1, '2015-12-18 07:26:55', '2015-12-18 07:26:55'),
(189, 'LAMEGO', 0, 1, '', 'Largo da Sé 16', '', '', 177, 178, 228, 'mccsecretariaolamego@gmail.com', 'mccsecretariaolamego@gmail.com', '', '', '', '', 1, 'Email devuelto. ', 1, '#673ab7', 1, '2015-12-18 07:28:26', '2016-01-09 17:33:24'),
(190, 'CEIRA', 0, 1, '', 'Rua a Boica 60 A Vendas de Ceira', '', '3030', 177, 179, 229, '', '', '', '', '', '', 1, '', 1, '#ff0000', 1, '2015-12-18 07:29:38', '2015-12-18 07:29:38'),
(191, 'TORRES VEDRAS', 0, 1, '', 'Igreja San Pedro', 'Apartado 182', '2564.911', 177, 180, 230, '', '', '', '', '', '', 1, '', 1, '#eee8aa', 1, '2015-12-18 07:30:45', '2015-12-18 07:30:45'),
(192, 'MENDOZA', 0, 1, '', 'Suipacha 634', '', '5500', 13, 181, 231, 'palancasmccmendoza@yahoo.com.ar', 'palancasmccmendoza@yahoo.com.ar', '', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-18 09:24:31', '2015-12-18 09:24:31'),
(193, 'MERCEDES LUJAN', 0, 1, '', 'C/. 18 y 5 nº 103  Delia De Landini', '', '6600', 13, 183, 232, 'mbfneila@hotmail.com', 'mbfneila@hotmail.com', '', '', '', '', 2, '', 1, '#ff4500', 1, '2015-12-18 09:26:47', '2015-12-18 09:26:47'),
(194, 'AVELLANEDA-LANÚS', 0, 1, '', 'C/. Lacarra 345', '', '1870', 13, 184, 233, 'mcc.cyp.avelanus@hotmail.com', 'mcc.cyp.avelanus@hotmail.com', '', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-18 09:28:32', '2015-12-18 09:28:32'),
(195, 'BUENOS AIRES', 0, 1, '', 'c/. Hidalgo 1784', '', '1414', 13, 185, 234, 'mebarquiza@yahoo.com.ar', 'mebarquiza@yahoo.com.ar', '', '', '', '', 2, '', 1, '#800000', 1, '2015-12-18 09:30:01', '2015-12-18 09:30:01'),
(196, 'BAHÍA BLANCA', 0, 1, '', 'c/. Rondeau 520', '', '8000', 13, 186, 235, 'escservmccbb@gmail.com', 'escservmccbb@gmail.com', '', '', '', '', 2, '', 1, '#2196f3', 1, '2015-12-18 09:31:29', '2015-12-18 09:31:29'),
(197, 'RESISTENCIA-CHACO', 0, 1, '', 'c/. San Buenaventura del Monte Alto 54', '', '3500', 13, 187, 236, 'mccresistencia@gmail.com', 'mccresistencia@gmail.com', 'http://cursilloresistencia.com.ar', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-18 09:33:11', '2015-12-18 09:33:11'),
(198, 'CORRIENTES', 0, 1, '', '', '', '', 13, 188, 237, 'bettybuongiorno@yahoo.com.ar', 'bettybuongiorno@yahoo.com.ar', 'mcc-corrientes.org.ar', '', '', '', 2, '', 1, '#66cdaa', 1, '2015-12-18 09:34:38', '2015-12-18 09:34:38'),
(199, 'CÓRDOBA', 0, 1, '', 'c/. Figueroa Alcorta 458', '', '5000', 13, 189, 239, 'mcc-palancascordoba@gmail.com', 'mcc-palancascordoba@gmail.com', '', '', '', '', 1, 'email devuelto', 1, '#da70d6', 1, '2015-12-18 09:36:07', '2016-01-09 16:59:38'),
(200, 'MERLO MORENO', 0, 1, '', 'c/. Ayacucho 1097', '', '1722', 13, 185, 240, 'palanca_mcc_merlomoreno@yahoo.com.ar', 'palanca_mcc_merlomoreno@yahoo.com.ar', '', '', '', '', 2, '', 1, '#daa520', 1, '2015-12-18 09:37:32', '2015-12-18 09:37:32'),
(201, 'SANTA FE', 0, 1, '', 'c/. Belgrano 3436', '', '', 13, 191, 241, 'mcc.santafe@gmail.com', 'mcc.santafe@gmail.com', 'www.santafe.org.ar', '', '', '', 2, '', 1, '#708090', 1, '2015-12-18 09:39:04', '2015-12-18 09:39:04'),
(202, 'SAN FRANCISCO', 0, 1, '', '', '', '', 13, 194, 242, 'palancamccsf@gmail.com', 'palancamccsf@gmail.com', 'www.elpartenon/mcc/', '', '', '', 2, '', 1, '#808000', 1, '2015-12-18 09:40:33', '2015-12-18 09:40:33'),
(203, 'SAN MIGUEL DE TUCUMAN', 0, 1, '', '', 'Casilla de Correo 104', '4000', 13, 195, 243, 'mccsanmiguelpalancas@hotmail.com', 'mccsanmiguelpalancas@hotmail.com', '', '', '', '', 2, '', 1, '#ff5722', 1, '2015-12-18 09:41:56', '2015-12-18 09:41:56'),
(204, 'SAN MARTIN', 0, 1, '', 'c/. Honorio Senet 2040', '', '1650', 13, 185, 244, 'cursillosanmartin@gmail.com', 'cursillosanmartin@gmail.com', 'http://mccescuela.fullblog.com.ar/', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 09:43:53', '2015-12-18 09:43:53'),
(205, 'SAN ISIDRO', 0, 1, '', 'Ituzaingó 90', '', 'b1642', 13, 185, 245, 'mccsanisidro@gmail.com', 'mccsanisidro@gmail.com', '', '', '', '', 2, '', 1, '#4caf50', 1, '2015-12-18 09:45:21', '2015-12-18 09:45:21'),
(206, '9 DE JULIO', 0, 1, '', '', '', '', 13, 198, 246, 'palancas9dejulio@gmail.com', 'palancas9dejulio@gmail.com', '', '', '', '', 2, '', 1, '#ff8c00', 1, '2015-12-18 09:46:35', '2015-12-18 09:46:35'),
(207, 'SAN RAFAEL', 0, 1, '', 'c/. San Luis 564', '', '5600', 13, 199, 247, 'risola@wilnet.com.ar', 'risola@wilnet.com.ar', '', '', '', '', 1, 'email devuelto', 1, '#add8e6', 1, '2015-12-18 09:47:43', '2016-01-09 16:26:22'),
(208, 'MAR DEL PLATA', 0, 1, '', 'c/. Malvina 245', '', '7600', 13, 200, 248, 'palancas@mccmardelplata.org.ar', 'palancas@mccmardelplata.org.ar', '', '', '', '', 1, 'Email devuelto', 1, '#bc8f8f', 1, '2015-12-18 09:51:05', '2016-01-09 17:13:06'),
(209, 'VIEDMA', 0, 1, '', 'c/. Irigoyen 71', '', '8500', 13, 201, 249, 'rufino.esposito@speedy.com.ar', 'rufino.esposito@speedy.com.ar', '', '', '', '', 2, '', 1, '#673ab7', 1, '2015-12-18 09:52:26', '2015-12-18 09:52:26'),
(210, 'VIRGEN DEL ROSARIO SAN NICOLÁS', 0, 1, '', '', '', '', 13, 185, 250, 'selectoenrique1@gmail.com', 'selectoenrique1@gmail.com', '', '', '', '', 2, '', 1, '#808000', 1, '2015-12-18 09:53:34', '2015-12-18 09:53:34'),
(211, 'TUCUMAN', 0, 1, '', '', '', '', 13, 195, 251, 'palancastucuman@yahoo.com.ar', 'palancastucuman@yahoo.com.ar', '', '', '', '', 2, '', 1, '#da70d6', 1, '2015-12-18 09:54:37', '2015-12-18 09:54:37'),
(212, 'SANTA ROSA', 0, 1, '', 'Bolívar 218 3º ', '', '', 13, 204, 252, 'palancassantarosa@gmail.com', 'palancassantarosa@gmail.com', '', '', '', '', 1, 'email devuelto', 1, '#cddc39', 1, '2015-12-18 09:55:49', '2016-01-09 16:22:53'),
(213, 'SANTIAGO DEL ESTERO', 0, 1, '', 'c/. Independencia 267', '', '4200', 13, 205, 253, 'andresmalica@hotmail.com', 'andresmalica@hotmail.com', '', '', '', '', 2, '', 1, '#ff00ff', 1, '2015-12-18 09:57:00', '2015-12-18 09:57:00'),
(214, 'MORON', 0, 1, '', 'c/ Nta Sra del Buen Viaje 936', '', '1708', 13, 185, 254, 'mccmoronpalancas@hotmail.com', 'mccmoronpalancas@hotmail.com', 'cursillistashurlingham.supersitio.net', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 09:58:55', '2015-12-18 09:58:55'),
(216, 'FERMO', 0, 1, '', '', 'Casella Postale 9', '63023', 112, 206, 255, 'cursillos.fermo@libero.it', 'cursillos.fermo@libero.it', '', '', '', '', 2, '', 1, '#66cdaa', 1, '2015-12-18 12:55:23', '2015-12-18 12:55:23'),
(217, 'GENOVA', 0, 1, '', 'Piazza Demarini 20R', '', '16123', 112, 207, 256, 'intendenze@cursillo.genova.it', 'intendenze@cursillo.genova.it', '', '', '', '', 2, '', 1, '#ff4500', 1, '2015-12-18 12:56:41', '2015-12-18 12:56:41'),
(218, 'TRAPANI', 0, 1, '', 'Parr S. Giuseppe  Vía F Crispi', '', '91014', 112, 208, 257, 'cursillointendenzetp@alice.it', 'cursillointendenzetp@alice.it', 'www.cursillostrapani.org', '', '', '', 2, '', 1, '#a52a2a', 1, '2015-12-18 12:58:43', '2015-12-18 12:58:43'),
(219, 'VICENZA', 0, 1, '', 'Via Mora 57 - I Casa d Inmacolata', '', '36100', 112, 209, 258, 'intendenze@cursillovicenza.org', 'intendenze@cursillovicenza.org', 'www.cursillovicenza.org', '', '', '', 2, '', 1, '#4caf50', 1, '2015-12-18 13:00:29', '2015-12-18 13:00:29'),
(220, 'AVERSA', 0, 1, '', 'Piazaa Marconi ', '', '81031', 112, 210, 259, 'intendenze@cursillosaversa.it', 'intendenze@cursillosaversa.it', 'www.cursillosaversa.it', '', '', '', 2, '', 1, '#5f9ea0', 1, '2015-12-18 13:34:23', '2015-12-18 13:34:23'),
(221, 'FIRENZE', 0, 1, '', 'Via de lle Mimose 14', '', '50142', 112, 211, 260, 'fi_mcc_fie@yahoo.it', 'fi_mcc_fie@yahoo.it', '', '', '', '', 2, '', 1, '#4682b4', 1, '2015-12-18 13:35:43', '2015-12-18 13:35:43'),
(222, 'GAETA', 0, 1, '', 'Parrocchia del Buon Pastore ', '', '', 112, 242, 261, 'cicala.maria@tiscali.it', 'cicala.maria@tiscali.it', '', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-18 13:37:24', '2015-12-18 13:37:24'),
(223, 'ROMA', 0, 1, '', 'Via Sette Chiese 139', '', '00145', 112, 213, 262, 'nicoferrantes69@gmail.com', 'nicoferrantes69@gmail.com', '', '', '', '', 1, 'email devuelto', 1, '#ff5722', 1, '2015-12-18 13:38:48', '2016-01-09 17:25:42'),
(224, 'PADOVA', 0, 1, '', 'Parrocchia Santa Rita Via S Rita 18', '', '35126', 112, 214, 263, 'ultreyapd@libero.it', 'ultreyapd@libero.it', 'http://cursillospadova.wordpress.com', '', '', '', 2, '', 1, '#da70d6', 1, '2015-12-18 13:41:22', '2015-12-18 13:41:22'),
(225, 'PERUGIA', 0, 1, '', 'Via Madonna Alta 98 Parr S Raffaele Arc', '', '06129', 112, 215, 264, 'intendenzepg@yahoo.it', 'intendenzepg@yahoo.it', '', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 13:42:57', '2015-12-18 13:42:57'),
(226, 'RAGUSA', 0, 1, '', 'Piazza Duomo 1', '', '97100', 112, 216, 265, 'segr.cursillosrg@libero.it', 'segr.cursillosrg@libero.it', '', '', '', '', 2, '', 1, '#cd5c5c', 1, '2015-12-18 13:44:18', '2015-12-18 13:44:18'),
(227, 'RAVENA', 0, 1, '', 'Via Pier Traverseir 41', '', '48121', 112, 217, 266, 'cursillos.ra@libero.it', 'cursillos.ra@libero.it', '', '', '', '', 2, '', 1, '#a9a9a9', 1, '2015-12-18 13:45:34', '2015-12-18 13:45:34'),
(228, 'BOLOGNA', 0, 1, '', 'Via Porrettana 121', '', '40135', 112, 218, 267, 'voltapagina2010@libero.it', 'intendenze@cursillosbologna.it', 'www.cursillosbologna.it', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 13:47:31', '2015-12-18 13:49:00'),
(229, 'CAGLIARI', 0, 1, '', '', 'Casilla Postale 229', '09100', 112, 219, 268, 'intendenzemccagliari@aruba.it', 'intendenzemccagliari@aruba.it', '', '', '', '', 1, 'email devuelto', 1, '#ff4500', 1, '2015-12-18 13:50:34', '2016-01-09 16:38:48'),
(230, 'ORISTANO', 0, 1, '', '', 'Casella Postale 63 Chiusa', '09170', 112, 220, 269, 'gruppointendenze.cursillo.or@gmail.com', 'gruppointendenze.cursillo.or@gmail.com', '', '', '', '', 2, '', 1, '#ff1493', 1, '2015-12-18 13:52:02', '2015-12-18 13:52:02'),
(231, 'JESI', 0, 1, '', 'Piazza Federico II  7', '', '60035', 112, 221, 270, 'cursillojesi@yahoo.it', 'cursillojesi@yahoo.it', '', '', '', '', 2, '', 1, '#4caf50', 1, '2015-12-18 13:53:17', '2015-12-18 13:53:17'),
(232, 'ASCOLI PICENO', 0, 1, '', '', 'Casella Postale 22', '63100', 112, 222, 271, 'intendenzecursilloap@gmail.com', 'intendenzecursilloap@gmail.com', '', '', '', '', 2, '', 1, '#708090', 1, '2015-12-18 13:54:28', '2015-12-18 13:54:28'),
(233, 'BENEVENTO', 0, 1, '', 'Via A Meomartini 102', '', '82100', 112, 223, 272, 'intendenze@cursillosbenevento.it', 'intendenze@cursillosbenevento.it', 'www.cursillosbenevento.it', '', '', '', 2, '', 1, '#8fbc8f', 1, '2015-12-18 13:55:57', '2015-12-18 13:55:57'),
(234, 'CALTAGIRONE', 0, 1, '', 'Via lep. Pe Umberto 67', '', '95041', 112, 224, 273, 'Isanalitro@yahoo.it', 'Isanalitro@yahoo.it', '', '', '', '', 1, 'email devuelto', 1, '#00fa9a', 1, '2015-12-18 13:57:34', '2016-01-09 16:37:19'),
(235, 'PRATO', 0, 1, '', 'Via Montalese 387', '', '59100', 112, 225, 274, 'cursillos.prato@libero.it', 'cursillos.prato@libero.it', '', '', '', '', 2, '', 1, '#32cd32', 1, '2015-12-18 13:58:47', '2015-12-18 13:58:47'),
(236, 'ASSISI', 0, 1, '', '', '', '', 112, 226, 275, 'intendenze.assisi@libero.it', 'intendenze.assisi@libero.it', 'www.cursillosassisi.altervista.org', '', '', '', 2, '', 1, '#4b0082', 1, '2015-12-18 14:00:27', '2015-12-18 14:00:27'),
(237, 'NARDO GALLIPOLI', 0, 1, '', 'Via Largo Fiera  Casa Madonna dell Alizza', '', '73011', 112, 227, 276, 'mcc@cursillonardogallipoli.it', 'mcc@cursillonardogallipoli.it', '', '', '', '', 1, 'email devuelto', 1, '#add8e6', 1, '2015-12-18 14:02:09', '2016-01-09 16:36:14'),
(238, 'ORIA', 0, 1, '', 'Seminario Vescovile c/ San Cosino', '', '72024', 112, 228, 277, 'famigliadellomonaco@libero.it', 'famigliadellomonaco@libero.it', 'www.cursillosoria.it', '', '', '', 1, 'email devuelto', 1, '#00fa9a', 1, '2015-12-18 14:04:20', '2016-01-09 16:34:23'),
(239, 'NUORO', 0, 1, '', 'Via Manzoni 2  c/o Parr N.S.Delle Grazie', '', '08100', 112, 229, 279, 'rojchg@tiscali.it', 'rojchg@tiscali.it', '', '', '', '', 2, '', 1, '#fa8072', 1, '2015-12-18 14:06:24', '2015-12-18 14:06:24'),
(240, 'MACERATA', 0, 1, '', 'Corso Cavour 80', '', '62100', 112, 230, 280, 'cursillos.macerata@libero.it', 'cursillos.macerata@libero.it', '', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-18 14:07:35', '2015-12-18 14:07:35'),
(241, 'SIRACUSA', 0, 1, '', 'Via Piazza Armerina 8', '', '96100', 112, 231, 281, 'cursillos.siracusa@virgilio.it', 'cursillos.siracusa@virgilio.it', 'http://cursillossiracusa.myblog.it', '', '', '', 2, '', 1, '#d2691e', 1, '2015-12-18 14:09:56', '2015-12-18 14:09:56');
INSERT INTO `comunidades` (`id`, `comunidad`, `esPropia`, `tipo_secretariado_id`, `responsable`, `direccion`, `direccion_postal`, `cp`, `pais_id`, `provincia_id`, `localidad_id`, `email_solicitud`, `email_envio`, `web`, `facebook`, `telefono1`, `telefono2`, `tipo_comunicacion_preferida_id`, `observaciones`, `esColaborador`, `color`, `activo`, `created_at`, `updated_at`) VALUES
(242, 'TIVOLI', 0, 1, '', '', 'Casella Postale 62', '000198', 112, 213, 282, 'fast@fast2.191.it', 'fast@fast2.191.it', 'www.cursillostivoli.it', '', '', '', 2, '', 1, '#add8e6', 1, '2015-12-18 14:11:34', '2015-12-18 14:11:34'),
(243, 'LECCE', 0, 1, '', 'Via Imperatore Adriano 79 Parr S Antonino', '', '73100', 112, 233, 283, 'cursillos.lecce@libero.it', 'cursillos.lecce@libero.it', '', '', '', '', 2, '', 1, '#5f9ea0', 1, '2015-12-18 14:12:58', '2015-12-18 14:12:58'),
(244, 'SASSARI', 0, 1, '', 'Parrocchia Sant Agostino', '', '07100', 112, 234, 284, 'epilloni@numera.it', 'epilloni@numera.it', 'http://freelosophy.tiscali.it', '', '', '', 2, '', 1, '#00ff00', 1, '2015-12-18 14:14:51', '2015-12-18 14:14:51'),
(245, 'ROSSANO', 0, 1, '', 'Palazzo Arcivescovile', '', '87067', 112, 235, 285, 'rossanocariati@yahoo.it', 'rossanocariati@yahoo.it', '', '', '', '', 1, 'Email devuelto', 1, '#a9a9a9', 1, '2015-12-18 14:16:24', '2016-01-09 16:30:25'),
(246, 'PESCARA', 0, 1, '', 'Via Lago di Posta 9', '', '65128', 112, 236, 286, 'cursillospe@libero.it', 'cursillospe@libero.it', '', '', '', '', 2, '', 1, '#ffc107', 1, '2015-12-18 14:17:31', '2015-12-18 14:17:31'),
(247, 'PALESTRINA', 0, 1, '', 'Viccolo del Duomo  7', '', '00036', 112, 213, 287, 'intendenze.cursillopalestrina@hotmail.it', 'intendenze.cursillopalestrina@hotmail.it', 'mccpalestrina.oneminutesite.it', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-18 14:19:21', '2015-12-18 14:19:21'),
(248, 'ANGELI-ASSISI', 0, 1, '', 'Fermo Posta Parrocchia', '', '06088', 112, 237, 288, '', '', '', '', '', '', 1, '', 1, '#ff4500', 1, '2015-12-18 14:20:20', '2015-12-18 14:20:20'),
(249, 'BIELLA', 0, 1, '', 'Parrocchia S Antonio', '', '13897', 112, 245, 297, 'cursillo.biella@gmail.com', 'cursillo.biella@gmail.com', '', '', '', '', 2, '', 1, '#000080', 1, '2015-12-18 14:21:42', '2015-12-18 14:21:42'),
(250, 'BRINDISI OSTUNI', 0, 1, '', 'Via XXV Parrocchia Santa Rita', '', '72019', 112, 239, 290, '', '', '', '', '', '', 1, '', 1, '#74d108', 1, '2015-12-18 14:23:01', '2015-12-18 14:23:01'),
(251, 'COSENZA BISIGNANO', 0, 1, '', 'c/ da Tocci  Seminario Arcivescovile', '', '', 112, 240, 291, 'mcc.cosenzabisignano@libero.it', 'mcc.cosenzabisignano@libero.it', '', '', '', '', 2, '', 1, '#b0c4de', 1, '2015-12-18 14:24:42', '2015-12-18 14:24:42'),
(252, 'FERRARA', 0, 1, '', 'Via Schiavoni 13  Valerio Mantovani', '', '44100', 112, 241, 292, '', '', '', '', '', '', 1, '', 1, '#fa8072', 1, '2015-12-18 14:25:44', '2015-12-18 14:25:44'),
(253, 'FIUMICINO', 0, 1, '', 'Via della Scafa 171', '', '00054', 112, 213, 293, '', '', '', '', '', '', 1, '', 1, '#00fa9a', 1, '2015-12-18 14:26:51', '2016-01-08 22:34:48'),
(254, 'FORMIA', 0, 1, '', 'Via Foce SNS Loc Gionola', '', '04023', 112, 242, 294, '', '', '', '', '', '', 1, '', 1, '#008080', 1, '2015-12-18 14:27:41', '2016-01-08 22:35:29'),
(255, 'MODENA', 0, 1, '', '', 'Casella Postale 40 M C', '41100', 112, 243, 295, 'modena@libero.it', 'modena@libero.it', '', '', '', '', 2, '', 1, '#03a9f4', 1, '2015-12-18 14:28:41', '2015-12-18 14:28:41'),
(256, 'NICHELINO', 0, 1, '', 'Via San Matteo 9', '', '10042', 112, 244, 296, '', '', '', '', '', '', 1, '', 1, '#00bcd4', 1, '2015-12-18 14:29:33', '2015-12-18 14:29:33'),
(257, 'OCCHIEPPO INFERIORE', 0, 1, '', 'Parrocchia de San Antonino', '', '13897', 112, 245, 297, 'cursillosbiella@gmail.com', 'cursillosbiella@gmail.com', '', '', '', '', 2, '', 1, '#cddc39', 1, '2015-12-18 14:31:01', '2015-12-20 14:25:31'),
(258, 'PATERNÓ', 0, 1, '', '', 'Casella Postale 34', '95047', 112, 246, 298, '', '', '', '', '', '', 1, '', 1, '#a9a9a9', 1, '2015-12-18 14:31:48', '2015-12-18 14:31:48'),
(259, 'TERNI', 0, 1, '', '', 'Casella Postale 140', '05100', 112, 247, 299, '', '', '', '', '', '', 1, '', 1, '#98fb98', 1, '2015-12-18 14:32:28', '2015-12-18 14:32:28'),
(260, 'TORINO', 0, 1, '', 'Via San Matteo 1', '', '10142', 112, 244, 296, 'cursillos.torino@tiscali.it', 'cursillos.torino@tiscali.it', '', '', '', '', 2, '', 1, '#bc8f8f', 1, '2015-12-18 14:33:47', '2015-12-18 14:33:47'),
(261, 'TRENTO', 0, 1, '', 'Via A. Schmid 24  c/o Bortolotti Giuliana', '', '38121', 112, 250, 304, 'cursillos.trento@libero.it', 'cursillos.trento@libero.it', '', '', '', '', 1, 'Email devuelto', 1, '#ff0000', 1, '2015-12-18 14:36:06', '2016-01-14 09:53:10'),
(262, 'TREVISO', 0, 1, '', 'Via Paganini 6', '', '31100', 112, 251, 305, 'intendenze.mcc.treviso@gmail.com', 'intendenze.mcc.treviso@gmail.com', '', '', '', '', 2, '', 1, '#ffff00', 1, '2015-12-18 14:37:22', '2016-01-13 15:16:58'),
(263, 'TRIESTE', 0, 1, '', 'Piazzale Gioberti 5  Parr Giovanni Dec.', '', '34128', 112, 252, 306, 'cursillos.trieste@liberto.it', 'cursillos.trieste@liberto.it', '', '', '', '', 1, 'Email devuelto', 1, '#ffeb3b', 1, '2015-12-18 14:38:51', '2016-01-09 16:16:23'),
(264, 'UGENTO', 0, 1, '', 'Largo Duomo 4', '', '73059', 112, 233, 307, 'cursillos.trieste@liberto.it', 'cursillos.trieste@liberto.it', 'www.cursillosugentosmdilema.it', '', '', '', 2, '', 1, '#3cb371', 1, '2015-12-18 14:40:47', '2015-12-18 14:40:47'),
(265, 'TORTONA', 0, 1, '', 'Via Roma 97/2   Isola del Cantone', '', '16017', 112, 207, 303, 'sabrianto@virgilio.it', 'sabrianto@virgilio.it', '', '', '', '', 2, '', 1, '#98fb98', 1, '2015-12-18 14:46:45', '2015-12-18 14:46:45'),
(266, 'GOIANIA', 0, 2, '', '', 'Caixa Postal 275', '74000.970', 33, 72, 111, 'secged.gyn@hotmail.com', 'secged.gyn@hotmail.com', '', '', '', '', 2, '', 1, '#ffff00', 1, '2015-12-18 16:44:59', '2015-12-18 16:44:59'),
(267, 'COMUNIDAD DE CONTROL', 0, 1, 'Paulino', '', '', '98765', 242, 260, 309, 'pmgcur@gmail.com', 'pmgcur01@gmail.com', '', '', '', '', 2, 'Creada por Paulino para controlar la recepción de mensajes por correo electrónico', 1, '#ff0000', 1, '2015-12-28 15:52:44', '2015-12-28 15:52:44'),
(269, 'ASTURIAS', 0, 1, '', '', 'Apartado de Correos 312', '33080', 73, 261, 311, 'Decolores.Asturias@gmail.com', 'Decolores.Asturias@gmail.com', 'www.cursillosdecristiandadasturias.es', '', '', '', 2, '', 1, '#00ff00', 1, '2015-12-31 09:35:07', '2016-01-13 11:49:15'),
(270, 'CALATAYUD', 0, 1, '', 'Casa de la Iglesia Pº Ramón y Cajal 6', ' ', '50800', 73, 47, 312, '', '', '', '', '', '', 1, '', 1, '#d3d3d3', 1, '2016-01-13 11:46:45', '2016-01-13 11:46:45'),
(271, 'PALM BEACH', 0, 1, '', '', '', '', 75, 137, 313, 'palancasmccpalmbeach@gmail.com', 'palancasmccpalmbeach@gmail.com', 'www.mccdepalmbeach.org', '', '', '', 2, '', 1, '#add8e6', 1, '2016-01-25 22:17:19', '2016-01-25 22:17:19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cursillos`
--

CREATE TABLE `cursillos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cursillo` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Cursillo para la cristiandad',
  `num_cursillo` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_final` date NOT NULL,
  `descripcion` text COLLATE utf8_unicode_ci NOT NULL,
  `comunidad_id` bigint(20) UNSIGNED NOT NULL,
  `tipo_participante_id` bigint(20) UNSIGNED NOT NULL,
  `esRespuesta` tinyint(1) NOT NULL DEFAULT '0',
  `esSolicitud` tinyint(1) NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:39',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:39'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `cursillos`
--

INSERT INTO `cursillos` (`id`, `cursillo`, `num_cursillo`, `fecha_inicio`, `fecha_final`, `descripcion`, `comunidad_id`, `tipo_participante_id`, `esRespuesta`, `esSolicitud`, `activo`, `created_at`, `updated_at`) VALUES
(12, 'Cursillo de Cristiandad', '167', '2016-02-25', '2016-02-28', '', 7, 3, 0, 0, 1, '2015-12-12 13:34:11', '2015-12-12 13:34:11'),
(13, 'Cursillo de Cristiandad', '168', '2016-04-14', '2016-04-17', '', 7, 3, 0, 0, 1, '2015-12-12 13:35:18', '2015-12-12 13:35:18'),
(14, 'Cursillo de Cristiandad', '169', '2016-06-16', '2016-06-19', '', 7, 3, 0, 0, 1, '2015-12-12 13:36:07', '2015-12-12 13:36:07'),
(15, 'Cursillo de Cristiandad', '170', '2016-08-04', '2016-08-07', '', 7, 3, 0, 0, 1, '2015-12-12 13:36:49', '2015-12-12 13:36:49'),
(16, 'Cursillo de Cristiandad', '171', '2016-11-03', '2016-11-06', '', 7, 3, 0, 0, 1, '2015-12-12 13:38:04', '2015-12-12 13:38:04'),
(17, 'CURSILLO DE CRISTIANDAD', '315', '2016-01-21', '2016-01-24', ' A celebrar en Loeches', 40, 3, 0, 0, 1, '2016-01-13 11:54:57', '2016-01-13 11:54:57'),
(18, 'CURSILLO DE CRISTIANDAD', '235', '2016-02-04', '2016-02-07', 'A celebrar en Collado Villalba', 40, 2, 0, 0, 1, '2016-01-13 11:56:33', '2016-01-13 11:56:33'),
(19, 'CURSILLO DE CRISTIANDAD', '465', '2016-02-18', '2016-02-21', 'A celebrar en Collado Villalba', 40, 1, 0, 0, 1, '2016-01-13 11:57:51', '2016-01-13 11:57:51'),
(20, 'CURSILLO DE CRISTIANDAD', '316', '2016-03-03', '2016-03-06', 'A celebrar en Collado Villalba', 40, 3, 0, 0, 1, '2016-01-13 11:58:50', '2016-01-13 11:58:50'),
(21, 'CURSILLO DE CRISTIANDAD', '000', '2016-03-31', '2016-04-03', 'A celebrar en París, Francia', 40, 3, 0, 0, 1, '2016-01-13 12:00:28', '2016-01-13 12:00:28'),
(22, 'CURSILLO DE CRISTIANDAD', '317', '2016-04-07', '2016-04-10', 'A celebrar en Collado Villalba', 40, 3, 0, 0, 1, '2016-01-13 12:01:52', '2016-01-13 12:01:52'),
(23, 'CURSILLO DE CRISTIANDAD', '318', '2016-04-21', '2016-04-24', 'A celebrar en Collado Villalba', 40, 3, 0, 0, 1, '2016-01-13 12:02:58', '2016-01-13 12:02:58'),
(24, 'CURSILLO DE CRISTIANDAD', '319', '2016-04-29', '2016-05-02', 'A celebrar en Collado Villalba', 40, 3, 0, 0, 1, '2016-01-13 12:04:26', '2016-01-13 12:04:26'),
(25, 'CURSILLO DE CRISTIANDAD', '320', '2016-06-02', '2016-06-05', 'A celebrar en Loeches', 40, 3, 0, 0, 1, '2016-01-13 12:05:28', '2016-01-13 12:05:28'),
(27, 'CURSILLO DE CRISTIANDAD', '321', '2016-06-16', '2016-06-19', 'A celebrar en Collado Villalba', 40, 3, 0, 0, 1, '2016-01-13 12:07:20', '2016-01-13 12:07:20'),
(28, 'CURSILLO DE CRISTIANDAD', '69', '2016-02-05', '2016-02-08', '', 13, 3, 0, 0, 1, '2016-01-13 12:10:45', '2016-01-13 12:10:45'),
(29, 'CURSILLO DE CRISTIANDAD', '70', '2016-04-29', '2016-05-02', '', 13, 3, 0, 0, 1, '2016-01-13 12:11:34', '2016-01-13 12:11:34'),
(30, 'CURSILLO DE CRISTIANDAD', '71', '2016-07-22', '2016-07-25', '', 13, 3, 0, 0, 1, '2016-01-13 12:12:27', '2016-01-13 12:12:27'),
(31, 'CURSILLO DE CRISTIANDAD', '72', '2016-10-06', '2016-10-09', '', 13, 3, 0, 0, 1, '2016-01-13 12:13:12', '2016-01-13 12:13:12'),
(32, 'CURSILLO DE CRISTIANDAD', '73', '2016-12-05', '2016-12-08', '', 13, 3, 0, 0, 1, '2016-01-13 12:14:01', '2016-01-13 12:14:01'),
(33, 'CURSILLO DE CRISTIANDAD ', '490', '2016-01-21', '2016-01-24', 'Caja Ejercicios Latore', 269, 3, 0, 0, 1, '2016-01-13 12:16:13', '2016-01-13 12:16:13'),
(34, 'CURSILLO DE CRISTIANDAD', '309', '2016-01-27', '2016-01-30', '', 179, 1, 0, 0, 1, '2016-01-13 12:33:12', '2016-01-13 12:33:12'),
(35, 'CURSILLO DE CRISTIANDAD', '249', '2016-02-10', '2016-02-13', '', 179, 2, 0, 0, 1, '2016-01-13 12:34:06', '2016-01-13 12:34:06'),
(36, 'CURSILLO DE CRISTIANDAD', '310', '2016-03-09', '2016-03-12', '', 179, 1, 0, 0, 1, '2016-01-13 12:35:04', '2016-01-13 12:35:04'),
(37, 'CURSILLO DE CRISTIANDAD', '250', '2016-04-27', '2016-04-30', '', 179, 2, 0, 0, 1, '2016-01-13 12:35:57', '2016-01-13 12:35:57'),
(38, 'CURSILLO DE CRISTIANDAD', '311', '2016-06-15', '2016-06-18', '', 179, 1, 0, 0, 1, '2016-01-13 12:36:50', '2016-01-13 12:36:50'),
(39, 'CURSILLO DE CRISTIANDAD', '251', '2016-07-13', '2016-07-16', '', 179, 2, 0, 0, 1, '2016-01-13 12:38:18', '2016-01-13 12:38:18'),
(40, 'CURSILLO DE CRISTIANDAD', '312', '2016-10-26', '2016-10-29', '', 179, 1, 0, 0, 1, '2016-01-13 12:39:16', '2016-01-13 12:39:16'),
(41, 'CURSILLO DE CRISTIANDAD', '252', '2016-11-23', '2016-11-26', '', 179, 2, 0, 0, 1, '2016-01-13 12:41:12', '2016-01-13 12:41:12'),
(42, 'CURSILLO DE CRISTIANDAD', '114', '2016-01-21', '2016-01-24', '', 111, 2, 0, 0, 1, '2016-01-13 15:26:29', '2016-01-13 15:26:29'),
(43, 'CURSILLO DE CRISTIANDAD', '139', '2016-02-11', '2016-02-14', '', 111, 1, 0, 0, 1, '2016-01-13 15:27:19', '2016-01-13 15:27:19'),
(44, 'CURSILLO DE CRISTIANDAD', '80', '2016-02-18', '2016-02-21', '', 216, 2, 0, 0, 1, '2016-01-13 15:28:35', '2016-01-13 15:28:35'),
(45, 'CURSILLO DE CRISTIANDAD', '50', '2016-02-18', '2016-02-21', '', 240, 2, 0, 0, 1, '2016-01-13 15:29:40', '2016-01-13 15:29:40'),
(46, 'CURSILLO DE CRISTIANDAD', '58', '2016-04-07', '2016-04-10', '', 240, 1, 0, 0, 1, '2016-01-13 15:30:28', '2016-01-13 15:30:28'),
(47, 'CURSILLO DE CRISTIANDAD', '75', '2016-01-27', '2016-01-30', '', 184, 1, 0, 0, 1, '2016-01-15 10:11:31', '2016-01-15 10:11:31'),
(48, 'CURSILLO DE CRISTIANDAD', '72', '2016-02-24', '2016-02-27', '', 184, 2, 0, 0, 1, '2016-01-15 10:12:28', '2016-01-15 10:12:28'),
(49, 'CURSILLO DE CRISTIANDAD', '76', '2016-04-20', '2016-04-23', '', 184, 1, 0, 0, 1, '2016-01-15 10:13:15', '2016-01-15 10:13:15'),
(50, 'CURSILLO DE CRISTIANDAD', '73', '2016-06-01', '2016-06-04', '', 184, 2, 0, 0, 1, '2016-01-15 10:14:05', '2016-01-15 10:14:05'),
(51, 'CURSILLO DE CRISTIANDAD', '70', '2016-02-03', '2016-02-06', '', 239, 1, 0, 0, 1, '2016-01-17 09:45:58', '2016-01-17 09:45:58'),
(52, 'CURSILLO DE CRISTIANDAD', '66', '2016-03-09', '2016-03-12', '', 239, 2, 0, 0, 1, '2016-01-17 09:46:41', '2016-01-17 09:46:41'),
(53, 'CURSILLO DE CRISTIANDAD', '40', '2016-04-24', '2016-04-24', '', 239, 3, 0, 0, 1, '2016-01-17 09:47:49', '2016-01-17 09:47:49'),
(54, 'CURSILLO DE CRISTIANDAD', '52', '2016-02-04', '2016-02-07', '', 271, 1, 0, 0, 1, '2016-01-25 22:19:03', '2016-01-25 22:19:03'),
(55, 'CURSILLO DE CRISTIANDAD', '52', '2016-02-04', '2016-02-07', '', 271, 2, 0, 0, 1, '2016-01-25 22:19:46', '2016-01-25 22:19:46'),
(56, 'CURSILLO DE CRISTIANDAD', '171', '2016-04-15', '2016-04-17', '', 74, 1, 0, 0, 1, '2016-01-30 10:52:35', '2016-01-30 10:52:35'),
(57, 'CURSILLO DE CRISTIANDAD', '171', '2016-06-03', '2016-06-05', '', 74, 2, 0, 0, 1, '2016-01-30 10:53:41', '2016-01-30 10:53:41'),
(58, 'CURSILLO DE CRISTIANDAD', '172', '2016-06-17', '2016-06-19', '', 74, 1, 0, 0, 1, '2016-01-30 10:54:37', '2016-01-30 10:54:37'),
(59, 'CURSILLO DE CRISTIANDAD', '172', '2016-07-08', '2016-07-10', '', 74, 2, 0, 0, 1, '2016-01-30 10:55:31', '2016-01-30 10:55:31'),
(60, 'CURSILLO DE CRISTIANDAD', '173', '2016-08-19', '2016-08-21', '', 74, 1, 0, 0, 1, '2016-01-30 10:56:16', '2016-01-30 10:56:16'),
(61, 'CURSILLO DE CRISTIANDAD', '173', '2016-09-23', '2016-09-25', '', 74, 2, 0, 0, 1, '2016-01-30 10:56:58', '2016-01-30 10:56:58'),
(62, 'CURSILLO DE CRISTIANDAD', '174', '2016-10-14', '2016-10-16', '', 74, 1, 0, 0, 1, '2016-01-30 10:57:39', '2016-01-30 10:57:39'),
(63, 'CURSILLO DE CRISTIANDAD', '174', '2016-11-18', '2016-11-20', '', 74, 2, 0, 0, 1, '2016-01-30 10:58:21', '2016-01-30 10:58:21'),
(64, 'CURSILLO DE CRISTIANDAD', '379', '2016-02-18', '2016-02-21', '', 178, 2, 0, 0, 1, '2016-01-30 11:05:04', '2016-01-30 11:05:04'),
(65, 'CURSILLO DE CRISTIANDAD', '533', '2016-02-25', '2016-02-28', '', 178, 1, 0, 0, 1, '2016-01-30 11:05:43', '2016-01-30 11:05:43'),
(66, 'CURSILLO DE CRISTIANDAD', '25', '2016-02-19', '2016-02-21', '', 76, 1, 0, 0, 1, '2016-02-01 11:48:57', '2016-02-01 11:48:57');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidades`
--

CREATE TABLE `localidades` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `localidad` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `provincia_id` bigint(20) UNSIGNED NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:32',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:32'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `localidades`
--

INSERT INTO `localidades` (`id`, `localidad`, `provincia_id`, `activo`, `created_at`, `updated_at`) VALUES
(2, 'Aguimes', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(3, 'Antigua', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(4, 'Arrecife', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(5, 'Artenara', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(6, 'Arucas', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(7, 'Betancuria', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(8, 'Firgas', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(9, 'Galdar', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(10, 'Guia', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(11, 'Haria', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(12, 'Ingenio', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(13, 'La Aldea de San Nicolas', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(14, 'La Oliva', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(15, 'Las Palmas de Gran Canaria', 1, 1, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(16, 'Mogan', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(17, 'Moya', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(18, 'Pajara', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(19, 'Puerto del Rosario', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(20, 'San Bartolome', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(21, 'San Bartolome de Tirajana', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(22, 'Santa Brigida', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(23, 'Santa Lucia de Tirajana', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(24, 'Tejeda', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(25, 'Telde', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(26, 'Teguise', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(27, 'Teror', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(28, 'Tias', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(29, 'Tinajo', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(30, 'Tuineje', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(31, 'Valleseco', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(32, 'Valsequillo', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(33, 'Vega de San Mateo', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(34, 'Yaiza', 1, 0, '2015-12-10 17:06:43', '2015-12-10 17:06:43'),
(37, 'Medellín', 5, 1, '2015-12-15 16:58:48', '2015-12-15 16:58:48'),
(39, 'ALBACETE', 15, 1, '2015-12-15 22:07:35', '2015-12-15 22:07:35'),
(40, 'ALMERÍA', 16, 1, '2015-12-15 22:08:01', '2015-12-15 22:08:01'),
(41, 'ASTORGA', 28, 1, '2015-12-15 22:08:25', '2015-12-15 22:08:25'),
(42, 'AVILA', 18, 1, '2015-12-15 22:08:56', '2015-12-15 22:08:56'),
(43, 'BADAJOZ', 19, 1, '2015-12-15 22:09:26', '2015-12-15 22:09:26'),
(44, 'BARCELONA', 20, 1, '2015-12-15 22:09:47', '2015-12-15 22:09:47'),
(45, 'BURGOS', 6, 1, '2015-12-15 22:12:54', '2015-12-15 22:12:54'),
(46, 'CÁDIZ', 7, 1, '2015-12-15 22:13:17', '2015-12-15 22:13:17'),
(47, 'LOGROÑO', 8, 1, '2015-12-15 22:13:37', '2015-12-15 22:13:37'),
(48, 'MURCIA', 9, 1, '2015-12-15 22:13:55', '2015-12-15 22:13:55'),
(49, 'CIUDAD REAL', 10, 1, '2015-12-15 22:14:14', '2015-12-15 22:14:14'),
(50, 'CÓRDOBA', 11, 1, '2015-12-15 22:14:35', '2015-12-15 22:14:35'),
(51, 'ALAVA', 55, 1, '2015-12-15 22:14:48', '2015-12-16 11:09:41'),
(52, 'CUENCA', 13, 1, '2015-12-15 22:15:05', '2015-12-15 22:15:05'),
(53, 'GERONA', 22, 1, '2015-12-15 22:15:33', '2015-12-15 22:15:33'),
(54, 'ALCORCÓN', 23, 1, '2015-12-15 22:16:14', '2015-12-15 22:16:14'),
(55, 'GRANADA', 24, 1, '2015-12-15 22:16:35', '2015-12-15 22:16:35'),
(56, 'GUADIX', 24, 1, '2015-12-15 22:16:58', '2015-12-15 22:16:58'),
(57, 'HUELVA', 25, 1, '2015-12-15 22:17:14', '2015-12-15 22:17:14'),
(58, 'SABIÑÁNIGO', 26, 1, '2015-12-15 22:17:40', '2015-12-15 22:17:40'),
(59, 'JAÉN', 27, 1, '2015-12-15 22:17:58', '2015-12-15 22:17:58'),
(60, 'JEREZ DE LA FRA', 7, 1, '2015-12-15 22:18:31', '2015-12-15 22:18:31'),
(61, 'LEÓN', 28, 1, '2015-12-15 22:18:46', '2015-12-15 22:18:46'),
(62, 'LÉRIDA', 29, 1, '2015-12-15 22:19:01', '2015-12-15 22:19:01'),
(63, 'LUGO', 30, 1, '2015-12-15 22:19:19', '2015-12-15 22:19:19'),
(64, 'MADRID', 23, 1, '2015-12-15 22:19:43', '2015-12-15 22:19:43'),
(65, 'MÁLAGA', 31, 1, '2015-12-15 22:20:06', '2015-12-15 22:20:06'),
(66, 'PALMA DE MALLORCA', 32, 1, '2015-12-15 22:20:25', '2015-12-15 22:20:25'),
(67, 'ORENSE', 33, 1, '2015-12-15 22:21:15', '2015-12-15 22:21:15'),
(68, 'PINOSO', 34, 1, '2015-12-15 22:21:43', '2015-12-15 22:21:43'),
(69, 'SORIA', 35, 1, '2015-12-15 22:22:02', '2015-12-15 22:22:02'),
(71, 'PALENCIA', 37, 1, '2015-12-15 22:22:44', '2015-12-15 22:22:44'),
(72, 'PAMPLONA', 38, 1, '2015-12-15 22:23:12', '2015-12-15 22:23:12'),
(73, 'SALAMANCA', 39, 1, '2015-12-15 22:23:35', '2015-12-15 22:23:35'),
(74, 'SAN SEBASTIÁN', 40, 1, '2015-12-15 22:24:10', '2015-12-15 22:24:10'),
(75, 'SANTANDER', 41, 1, '2015-12-15 22:24:32', '2015-12-15 22:24:32'),
(76, 'SANTIAGO DE COMPOSTELA', 42, 1, '2015-12-15 22:24:53', '2015-12-15 22:24:53'),
(77, 'CASTELLÓN', 43, 1, '2015-12-15 22:25:24', '2015-12-15 22:25:24'),
(78, 'SEGOVIA', 44, 1, '2015-12-15 22:25:50', '2015-12-15 22:25:50'),
(79, 'SEVILLA', 45, 1, '2015-12-15 22:26:09', '2015-12-15 22:26:09'),
(80, 'GUADALAJARA', 46, 1, '2015-12-15 22:26:25', '2015-12-15 22:26:25'),
(81, 'CALATAYUD', 47, 1, '2015-12-15 22:26:52', '2015-12-15 22:26:52'),
(82, 'LA LAGUNA', 48, 1, '2015-12-15 22:27:21', '2015-12-15 22:27:21'),
(83, 'TERUEL', 49, 1, '2015-12-15 22:27:53', '2015-12-15 22:27:53'),
(84, 'TALAVERA DE LA REINA', 50, 1, '2015-12-15 22:28:19', '2015-12-15 22:28:19'),
(85, 'TORTOSA', 51, 1, '2015-12-15 22:28:39', '2015-12-15 22:28:39'),
(86, 'VIGO', 52, 1, '2015-12-15 22:29:04', '2015-12-15 22:29:04'),
(88, 'VALENCIA', 53, 1, '2015-12-15 22:29:32', '2015-12-15 22:29:32'),
(89, 'VALLADOLID', 54, 1, '2015-12-15 22:29:59', '2015-12-15 22:29:59'),
(90, 'VITORIA', 55, 1, '2015-12-15 22:30:27', '2015-12-15 22:30:27'),
(91, 'ZAMORA', 56, 1, '2015-12-15 22:30:48', '2015-12-15 22:30:48'),
(92, 'ZARAGOZA', 47, 1, '2015-12-15 22:31:06', '2015-12-15 22:31:06'),
(93, 'ALCALÁ DE HENARES', 23, 1, '2015-12-15 22:35:38', '2015-12-15 22:35:38'),
(94, 'BILBAO', 60, 1, '2015-12-15 22:52:57', '2015-12-15 22:52:57'),
(95, 'GETAFE', 23, 1, '2015-12-15 23:10:47', '2015-12-15 23:10:47'),
(96, 'CÁCERES', 12, 1, '2015-12-16 11:10:55', '2015-12-16 11:10:55'),
(97, 'PLASENCIA', 19, 1, '2015-12-16 11:25:55', '2015-12-16 11:25:55'),
(98, 'DIVINOPOLIS', 61, 1, '2015-12-16 17:12:40', '2015-12-16 17:12:40'),
(100, 'ITAJUBÁ', 62, 1, '2015-12-16 20:04:16', '2015-12-16 20:04:16'),
(101, 'MARIANA', 63, 1, '2015-12-16 20:04:41', '2015-12-16 20:04:41'),
(102, 'MARINGÁ', 64, 1, '2015-12-16 20:05:16', '2015-12-16 20:05:16'),
(103, 'OURINHOS', 65, 1, '2015-12-16 20:05:43', '2015-12-16 20:05:43'),
(104, 'JALES', 66, 1, '2015-12-16 20:06:02', '2015-12-16 20:06:02'),
(105, 'JUNDIAÍ', 67, 1, '2015-12-16 20:07:42', '2015-12-16 20:07:42'),
(106, 'APUCARANA', 68, 1, '2015-12-16 20:08:11', '2015-12-16 20:08:11'),
(107, 'NOVA IGUAZÚ', 80, 1, '2015-12-16 20:08:40', '2015-12-16 20:08:40'),
(109, 'CAXIAS DO SUL RS', 70, 1, '2015-12-16 20:09:50', '2015-12-16 20:09:50'),
(110, 'FLORIANAPOLIS', 71, 1, '2015-12-16 20:10:19', '2015-12-16 20:10:19'),
(111, 'GOIANIA GO', 72, 1, '2015-12-16 20:10:55', '2015-12-16 20:10:55'),
(112, 'UMUAMARA', 64, 1, '2015-12-16 20:11:25', '2015-12-16 20:11:25'),
(113, 'ARACACATUBA SP', 74, 1, '2015-12-16 20:11:52', '2015-12-16 20:11:52'),
(114, 'CURITIBA PR', 75, 1, '2015-12-16 20:12:20', '2015-12-16 20:12:20'),
(115, 'RIO DO SUL Sta Catarina', 76, 1, '2015-12-16 20:13:04', '2015-12-16 20:13:04'),
(116, 'SANTA MARÍA RS', 77, 1, '2015-12-16 20:13:32', '2015-12-16 20:13:32'),
(117, 'ITUMBIARA GO', 78, 1, '2015-12-16 20:14:05', '2015-12-16 20:14:05'),
(118, 'MACEIÓ AL', 79, 1, '2015-12-16 20:14:25', '2015-12-16 20:14:25'),
(119, 'RIO DE JANEIRO', 80, 1, '2015-12-16 20:14:54', '2015-12-16 20:14:54'),
(121, 'ARACAJU SERGIPE', 83, 1, '2015-12-16 20:16:53', '2015-12-16 20:16:53'),
(122, 'BRASILIA DF', 84, 1, '2015-12-16 20:17:19', '2015-12-16 20:17:19'),
(123, 'ITAPETININGA SP', 85, 1, '2015-12-16 20:18:00', '2015-12-16 20:18:00'),
(124, 'BARAGANCA PAULISTA SP', 86, 1, '2015-12-16 20:19:07', '2015-12-16 20:19:07'),
(125, 'CAMPO MOURAO', 87, 1, '2015-12-16 20:19:32', '2015-12-16 20:19:32'),
(127, 'JATAÍ GO', 88, 1, '2015-12-16 20:26:59', '2015-12-16 20:26:59'),
(128, 'PETROPOLIS RJ', 89, 1, '2015-12-16 20:27:28', '2015-12-16 20:27:28'),
(129, 'URUGUAIANIA RS', 90, 1, '2015-12-16 20:27:54', '2015-12-16 20:27:54'),
(130, 'VACARIA', 91, 1, '2015-12-16 20:28:17', '2015-12-16 20:28:17'),
(131, 'PARANAVAÍ', 64, 1, '2015-12-16 20:28:50', '2015-12-16 20:28:50'),
(132, 'SAN JOSE DO RIO PRETO SP', 93, 1, '2015-12-16 20:29:15', '2015-12-16 20:29:15'),
(133, 'LEOPOLDINA MG', 94, 1, '2015-12-16 20:29:42', '2015-12-16 20:29:42'),
(134, 'PELOTAS RS', 95, 1, '2015-12-16 20:30:01', '2015-12-16 20:30:01'),
(135, 'CUIABÁ', 96, 1, '2015-12-16 20:30:23', '2015-12-16 20:30:23'),
(136, 'SOROCABA SP', 97, 1, '2015-12-16 20:30:43', '2015-12-16 20:30:43'),
(137, 'TABAUTÉ SP', 98, 1, '2015-12-16 20:31:11', '2015-12-16 20:31:11'),
(138, 'JACAREZHINO PR', 64, 1, '2015-12-16 20:31:42', '2015-12-16 20:31:42'),
(139, 'PARANATINGA MT', 100, 1, '2015-12-16 20:32:07', '2015-12-16 20:32:07'),
(140, 'ANÁPOLIS ', 101, 1, '2015-12-16 20:33:07', '2015-12-16 20:33:07'),
(143, 'VIITORIA', 81, 1, '2015-12-17 08:43:23', '2015-12-17 08:43:23'),
(144, 'CAXIAS DO SUL', 70, 1, '2015-12-17 10:00:01', '2015-12-17 10:00:01'),
(145, 'TEGUCIGALPA', 102, 1, '2015-12-17 10:55:00', '2015-12-17 10:55:00'),
(146, 'QUITO', 103, 1, '2015-12-17 10:58:08', '2015-12-17 10:58:08'),
(148, 'SAN SALVADOR', 106, 1, '2015-12-17 11:02:55', '2015-12-17 11:02:55'),
(149, 'PONCE', 107, 1, '2015-12-17 11:05:32', '2015-12-17 11:05:32'),
(150, 'TOKYO', 108, 1, '2015-12-17 11:08:31', '2015-12-17 11:08:31'),
(151, 'ROMANIA', 109, 1, '2015-12-17 11:44:04', '2015-12-17 11:44:04'),
(152, 'SANTIAGO DE CHILE', 113, 1, '2015-12-17 12:33:26', '2015-12-17 12:33:26'),
(154, 'SANTIAGO', 113, 1, '2015-12-17 12:34:36', '2015-12-17 12:34:36'),
(155, 'LOS ANGELES', 114, 1, '2015-12-17 12:35:00', '2015-12-17 12:35:00'),
(156, 'CHITRÉ', 115, 1, '2015-12-17 12:35:22', '2015-12-17 12:35:22'),
(157, 'PANAMÁ', 116, 1, '2015-12-17 12:35:46', '2015-12-17 12:35:46'),
(158, 'AREQUIPA', 117, 1, '2015-12-17 12:36:07', '2015-12-17 12:36:07'),
(159, 'ICA', 118, 1, '2015-12-17 12:36:36', '2015-12-17 12:36:36'),
(160, 'LIMA', 119, 1, '2015-12-17 12:37:09', '2015-12-17 12:37:09'),
(163, 'SANTIAGO RP', 120, 1, '2015-12-17 12:38:23', '2015-12-17 12:38:23'),
(164, 'LA VEGA', 121, 1, '2015-12-17 12:38:47', '2015-12-17 12:38:47'),
(165, 'CARMELO', 122, 1, '2015-12-17 12:39:14', '2015-12-17 12:39:14'),
(166, 'MONTEVIDEO', 123, 1, '2015-12-17 12:39:34', '2015-12-17 12:39:34'),
(167, 'SALTO', 124, 1, '2015-12-17 12:39:59', '2015-12-17 12:39:59'),
(168, 'SANTO DOMINGO', 125, 1, '2015-12-17 12:40:21', '2015-12-17 12:40:21'),
(169, 'SAN FRANCISCO DE MACORÍS', 125, 1, '2015-12-17 12:40:48', '2015-12-17 12:40:48'),
(172, 'VIÑA DEL MAR', 111, 1, '2015-12-17 15:32:11', '2015-12-17 15:32:11'),
(173, 'BATHURST', 128, 1, '2015-12-17 16:09:00', '2015-12-17 16:09:00'),
(174, 'CAMDEM', 127, 1, '2015-12-17 16:09:20', '2015-12-17 16:09:20'),
(175, 'KENTVILLE', 129, 1, '2015-12-17 16:12:19', '2015-12-17 16:12:19'),
(176, 'VICTORIA', 130, 1, '2015-12-17 16:12:50', '2015-12-17 16:12:50'),
(177, 'VANCOUVER', 131, 1, '2015-12-17 16:13:16', '2015-12-17 16:13:16'),
(178, 'BRNO', 135, 1, '2015-12-17 16:16:41', '2015-12-17 16:16:41'),
(180, 'JEJU CITY', 132, 1, '2015-12-17 18:17:19', '2015-12-17 18:17:19'),
(181, 'TAEGU', 133, 1, '2015-12-17 18:20:07', '2015-12-17 18:20:07'),
(182, 'SEOUL', 134, 1, '2015-12-17 18:22:35', '2015-12-17 18:22:35'),
(183, 'KEMPNER', 136, 1, '2015-12-17 20:16:25', '2015-12-17 20:16:25'),
(184, 'NAPLES', 137, 1, '2015-12-17 20:16:57', '2015-12-17 20:16:57'),
(185, 'AUSTIN', 136, 1, '2015-12-17 20:17:51', '2015-12-17 20:17:51'),
(186, 'HAWESVILLE ', 139, 1, '2015-12-17 20:18:19', '2015-12-17 20:18:19'),
(187, 'NEW YORK', 140, 1, '2015-12-17 20:18:42', '2015-12-17 20:18:42'),
(188, 'SAN DIEGO', 141, 1, '2015-12-17 20:19:06', '2015-12-17 20:19:06'),
(189, 'OKHALOMA', 142, 1, '2015-12-17 20:19:29', '2015-12-17 20:19:29'),
(190, 'COLORADO SPRINGS', 143, 1, '2015-12-17 20:19:50', '2015-12-17 20:19:50'),
(191, 'LITTLE ROCK', 144, 1, '2015-12-17 20:20:17', '2015-12-17 20:20:17'),
(192, 'MANCHESTER', 145, 1, '2015-12-17 20:20:58', '2015-12-17 20:20:58'),
(194, 'PHOENIX', 147, 1, '2015-12-17 20:21:40', '2015-12-17 20:21:40'),
(195, 'OAKLAND', 146, 1, '2015-12-17 20:22:04', '2015-12-17 20:22:04'),
(196, 'MIAMI', 137, 1, '2015-12-17 20:22:23', '2015-12-17 20:22:23'),
(198, 'LOS ANGELESS', 146, 1, '2015-12-17 20:49:55', '2015-12-17 20:49:55'),
(199, 'MONTERREY', 150, 1, '2015-12-17 21:03:46', '2015-12-17 21:03:46'),
(200, 'TAMPICO', 151, 1, '2015-12-17 21:04:05', '2015-12-17 21:04:05'),
(202, 'DURANGO', 154, 1, '2015-12-17 21:05:38', '2015-12-17 21:05:38'),
(203, 'ZAMORA', 155, 1, '2015-12-17 21:06:00', '2015-12-19 08:10:26'),
(204, 'SAN JUAN DE LOS LAGOS', 156, 1, '2015-12-17 21:06:24', '2015-12-17 21:06:24'),
(205, 'MÉRIDA', 157, 1, '2015-12-17 21:06:42', '2015-12-17 21:06:42'),
(206, 'TOLUCA DE SAN JOSÉ', 158, 1, '2015-12-17 21:07:07', '2015-12-17 21:07:07'),
(207, 'TULACINGO', 159, 1, '2015-12-17 21:07:32', '2015-12-17 21:07:32'),
(208, 'NUEVO CASAS GRANDES', 160, 1, '2015-12-17 21:08:10', '2015-12-17 21:08:10'),
(209, 'CIUDAD ALTAMIRANO', 161, 1, '2015-12-17 21:08:31', '2015-12-17 21:08:31'),
(210, 'XALAPA VER', 162, 1, '2015-12-17 21:08:59', '2015-12-17 21:08:59'),
(211, 'SALTILLO', 163, 1, '2015-12-17 21:09:19', '2015-12-17 21:09:19'),
(212, 'PUEBLA', 164, 1, '2015-12-17 21:09:37', '2015-12-17 21:09:37'),
(213, 'NOGALES', 165, 1, '2015-12-17 21:09:55', '2015-12-17 21:09:55'),
(214, 'PURÉPERO', 155, 1, '2015-12-17 21:10:18', '2015-12-17 21:10:18'),
(215, 'PIEDRAS NEGRAS', 167, 1, '2015-12-17 21:10:42', '2015-12-17 21:10:42'),
(216, 'LEÓN', 153, 1, '2015-12-17 21:11:15', '2015-12-19 08:10:50'),
(217, 'GUADALAJARA', 168, 1, '2015-12-17 21:13:21', '2015-12-19 08:09:36'),
(218, 'PORTO', 169, 1, '2015-12-18 07:05:04', '2015-12-18 07:05:04'),
(219, 'ANGRA DO HEROISMO', 170, 1, '2015-12-18 07:05:30', '2015-12-18 07:05:30'),
(220, 'PORTA DELGADA  SAN MIGUEL', 170, 1, '2015-12-18 07:05:58', '2015-12-18 07:05:58'),
(221, 'FUNCHAL', 171, 1, '2015-12-18 07:06:20', '2015-12-18 07:06:20'),
(222, 'AVEIRO', 172, 1, '2015-12-18 07:06:44', '2015-12-18 07:06:44'),
(223, 'VIANA DE CASTELO', 173, 1, '2015-12-18 07:07:03', '2015-12-18 07:07:03'),
(224, 'COIMBRA', 174, 1, '2015-12-18 07:07:24', '2015-12-18 07:07:24'),
(225, 'BRAGANZA MIRANDA', 175, 1, '2015-12-18 07:07:46', '2015-12-18 07:07:46'),
(226, 'VISEU', 176, 1, '2015-12-18 07:08:07', '2015-12-18 07:08:07'),
(227, 'BRAGA', 177, 1, '2015-12-18 07:08:25', '2015-12-18 07:08:25'),
(228, 'LAMEGO', 178, 1, '2015-12-18 07:08:43', '2015-12-18 07:08:43'),
(229, 'CEIRA', 179, 1, '2015-12-18 07:09:05', '2015-12-18 07:09:05'),
(230, 'TORRES VEDRAS', 180, 1, '2015-12-18 07:09:30', '2015-12-18 07:09:30'),
(231, 'MENDOZA', 181, 1, '2015-12-18 09:08:55', '2015-12-18 09:08:55'),
(232, 'MERCEDES', 183, 1, '2015-12-18 09:09:19', '2015-12-18 09:09:19'),
(233, 'AVELLANEDA', 184, 1, '2015-12-18 09:09:37', '2015-12-18 09:09:37'),
(234, 'BUENOS AIRES', 185, 1, '2015-12-18 09:10:04', '2015-12-18 09:10:04'),
(235, 'BAHÍA BLANCA', 186, 1, '2015-12-18 09:10:27', '2015-12-18 09:10:27'),
(236, 'RESISTENCIA-CHACO', 187, 1, '2015-12-18 09:10:54', '2015-12-18 09:10:54'),
(237, 'CORRIENTES', 188, 1, '2015-12-18 09:11:19', '2015-12-18 09:11:19'),
(239, 'CORDOBA', 189, 1, '2015-12-18 09:12:21', '2015-12-19 08:06:40'),
(240, 'MERLO', 185, 1, '2015-12-18 09:12:56', '2015-12-18 09:12:56'),
(241, 'SANTA FE', 191, 1, '2015-12-18 09:13:15', '2015-12-18 09:13:15'),
(242, 'SAN FRANCISCO', 194, 1, '2015-12-18 09:13:45', '2015-12-18 09:13:45'),
(243, 'SAN MIGUEL', 195, 1, '2015-12-18 09:16:12', '2015-12-18 09:16:12'),
(244, 'SAN MARTIN', 185, 1, '2015-12-18 09:16:30', '2015-12-18 09:16:30'),
(245, 'SAN ISIDRO', 185, 1, '2015-12-18 09:16:52', '2015-12-18 09:16:52'),
(246, '9 DE JULIO', 198, 1, '2015-12-18 09:17:21', '2015-12-18 09:17:21'),
(247, 'SAN RAFAEL', 199, 1, '2015-12-18 09:17:41', '2015-12-18 09:17:41'),
(248, 'MAR DEL PLATA', 200, 1, '2015-12-18 09:18:08', '2015-12-18 09:18:08'),
(249, 'VIEDMA', 201, 1, '2015-12-18 09:18:29', '2015-12-18 09:18:29'),
(250, 'VIRGEN DEL ROSARIO S.N.', 185, 1, '2015-12-18 09:19:10', '2015-12-18 09:19:10'),
(251, 'TUCUMAN', 195, 1, '2015-12-18 09:19:30', '2015-12-18 09:19:30'),
(252, 'SANTA ROSA', 204, 1, '2015-12-18 09:22:00', '2015-12-18 09:22:00'),
(253, 'SANTIAGO DEL ESTERO', 205, 1, '2015-12-18 09:22:23', '2015-12-18 09:22:23'),
(254, 'MORON', 185, 1, '2015-12-18 09:22:43', '2015-12-18 09:22:43'),
(255, 'FERMO', 206, 1, '2015-12-18 12:30:17', '2015-12-18 12:30:17'),
(256, 'GENOVA', 207, 1, '2015-12-18 12:30:37', '2015-12-18 12:30:37'),
(257, 'CASTELLMMARE DEL GOLFO', 208, 1, '2015-12-18 12:31:13', '2015-12-18 12:31:13'),
(258, 'VICENZA', 209, 1, '2015-12-18 12:31:38', '2015-12-18 12:31:38'),
(259, 'AVERSA', 210, 1, '2015-12-18 12:32:00', '2015-12-18 12:32:00'),
(260, 'FIRENZE', 211, 1, '2015-12-18 12:32:19', '2015-12-18 12:32:19'),
(261, 'PENITRO', 242, 1, '2015-12-18 12:33:11', '2015-12-18 12:33:11'),
(262, 'ROMA', 213, 1, '2015-12-18 12:33:30', '2015-12-18 12:33:30'),
(263, 'PADOVA', 214, 1, '2015-12-18 12:33:49', '2015-12-18 12:33:49'),
(264, 'PERUGIA', 215, 1, '2015-12-18 12:34:11', '2015-12-18 12:34:11'),
(265, 'RAGUSA', 216, 1, '2015-12-18 12:34:27', '2015-12-18 12:34:27'),
(266, 'RAVENA', 217, 1, '2015-12-18 12:34:47', '2015-12-18 12:34:47'),
(267, 'BOLOGNA', 218, 1, '2015-12-18 12:35:05', '2015-12-18 12:35:05'),
(268, 'CAGLIARI', 219, 1, '2015-12-18 12:35:23', '2015-12-18 12:35:23'),
(269, 'ORISTANO', 220, 1, '2015-12-18 12:35:41', '2015-12-18 12:35:41'),
(270, 'JESI', 221, 1, '2015-12-18 12:35:56', '2015-12-18 12:35:56'),
(271, 'ASCOLI PICENO', 222, 1, '2015-12-18 12:36:17', '2015-12-18 12:36:17'),
(272, 'BENEVENTO', 223, 1, '2015-12-18 12:36:33', '2015-12-18 12:36:33'),
(273, 'CALTAGIRONE', 224, 1, '2015-12-18 12:36:52', '2015-12-18 12:36:52'),
(274, 'PRATO', 225, 1, '2015-12-18 12:37:12', '2015-12-18 12:37:12'),
(275, 'GUALDO TADINO', 226, 1, '2015-12-18 12:37:42', '2015-12-18 12:37:42'),
(276, 'ALEZIO', 227, 1, '2015-12-18 12:38:07', '2015-12-18 12:38:07'),
(277, 'ORIA', 228, 1, '2015-12-18 12:38:38', '2015-12-18 12:38:38'),
(279, 'NUORO', 229, 1, '2015-12-18 12:39:00', '2015-12-18 12:39:00'),
(280, 'MACERATA', 230, 1, '2015-12-18 12:39:17', '2015-12-18 12:39:17'),
(281, 'SIRACUSA', 231, 1, '2015-12-18 12:39:33', '2015-12-18 12:39:33'),
(282, 'TIVOLI', 213, 1, '2015-12-18 12:39:57', '2015-12-18 12:39:57'),
(283, 'LECCE', 233, 1, '2015-12-18 12:40:14', '2015-12-18 12:40:14'),
(284, 'SASSARI', 234, 1, '2015-12-18 12:40:32', '2015-12-18 12:40:32'),
(285, 'ROSANNO', 235, 1, '2015-12-18 12:40:58', '2015-12-18 12:40:58'),
(286, 'PESCARA', 236, 1, '2015-12-18 12:41:14', '2015-12-18 12:41:14'),
(287, 'PALESTRINA', 213, 1, '2015-12-18 12:41:35', '2015-12-18 12:41:35'),
(288, 'ANGELI-ASSISI', 237, 1, '2015-12-18 12:42:03', '2015-12-18 12:42:03'),
(289, 'OCCHIEPO INFERIORE', 238, 1, '2015-12-18 12:42:44', '2015-12-18 12:42:44'),
(290, 'S VITO DEL NORMANNI', 239, 1, '2015-12-18 12:43:09', '2015-12-18 12:43:09'),
(291, 'RENDE', 240, 1, '2015-12-18 12:43:27', '2015-12-18 12:43:27'),
(292, 'FERRARA', 241, 1, '2015-12-18 12:43:42', '2015-12-18 12:43:42'),
(293, 'FIUMICINO', 213, 1, '2015-12-18 12:44:12', '2015-12-18 12:44:12'),
(294, 'FORMIA', 242, 1, '2015-12-18 12:44:29', '2015-12-18 12:44:29'),
(295, 'MODENA', 243, 1, '2015-12-18 12:44:51', '2015-12-18 12:44:51'),
(296, 'NICHELINO', 244, 1, '2015-12-18 12:45:11', '2015-12-18 12:45:11'),
(297, 'OCCHIEPPO INFERIORE', 245, 1, '2015-12-18 12:45:44', '2015-12-18 12:45:44'),
(298, 'PATERNÓ', 246, 1, '2015-12-18 12:46:50', '2015-12-18 12:46:50'),
(299, 'TERNI', 247, 1, '2015-12-18 12:47:09', '2015-12-18 12:47:09'),
(301, 'NICHELINNO', 248, 1, '2015-12-18 12:48:03', '2015-12-18 12:48:03'),
(303, 'GENOVA.', 207, 1, '2015-12-18 12:49:03', '2015-12-18 12:49:03'),
(304, 'TRENTO', 250, 1, '2015-12-18 12:49:24', '2015-12-18 12:49:24'),
(305, 'TREVISO', 251, 1, '2015-12-18 12:49:41', '2015-12-18 12:49:41'),
(306, 'TRIESTE', 252, 1, '2015-12-18 12:50:02', '2015-12-18 12:50:02'),
(307, 'UGENTO', 233, 1, '2015-12-18 12:50:26', '2015-12-18 12:50:26'),
(308, 'TORTONA', 207, 1, '2015-12-18 14:43:46', '2015-12-18 14:43:46'),
(309, 'TAMARACEITE', 260, 1, '2015-12-28 15:50:09', '2015-12-28 15:50:09'),
(311, 'OVIEDO', 261, 1, '2015-12-31 09:33:31', '2015-12-31 09:33:31'),
(312, 'CALATAYUD', 47, 1, '2016-01-13 11:44:08', '2016-01-13 11:44:08'),
(313, 'PALM BEACH', 137, 1, '2016-01-25 22:15:17', '2016-01-25 22:15:17');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2015_09_02_150000_create_colores_table', 1),
('2015_09_02_153233_create_paises_table', 1),
('2015_09_02_153241_create_provincias_table', 1),
('2015_09_02_153252_create_localidades_table', 1),
('2015_09_17_192401_create_roles_table', 1),
('2015_09_17_193826_create_users_table', 1),
('2015_09_17_193904_create_password_resets_table', 1),
('2015_09_17_193905_create_comunicaciones_preferidas_table', 1),
('2015_09_17_193910_create_tipos_participantes_table', 1),
('2015_09_17_194520_create_tipos_secretariados_table', 1),
('2015_09_17_194533_create_comunidades_table', 1),
('2015_09_17_194546_create_cursillos_table', 1),
('2015_11_01_105051_create_solicitudes_enviadas_table', 1),
('2015_11_01_105103_create_solicitudes_recibidas_table', 1),
('2016_01_13_172215_create_solicitudes_enviadas_cursillos_table', 1),
('2016_01_13_172326_create_solicitudes_recibidas_cursillos_table', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paises`
--

CREATE TABLE `paises` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pais` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `paises`
--

INSERT INTO `paises` (`id`, `pais`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Afganistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(2, 'Islas Gland', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(3, 'Albania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(4, 'Alemania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(5, 'Andorra', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(6, 'Angola', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(7, 'Anguilla', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(8, 'Antártida', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(9, 'Antigua y Barbuda', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(10, 'Antillas Holandesas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(11, 'Arabia Saudí', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(12, 'Argelia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(13, 'Argentina', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(14, 'Armenia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(15, 'Aruba', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(16, 'Australia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(17, 'Austria', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(18, 'Azerbaiyán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(19, 'Bahamas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(20, 'Bahréin', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(21, 'Bangladesh', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(22, 'Barbados', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(23, 'Bielorrusia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(24, 'Bélgica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(25, 'Belice', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(26, 'Benin', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(27, 'Bermudas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(28, 'Bhután', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(29, 'Bolivia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(30, 'Bosnia y Herzegovina', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(31, 'Botsuana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(32, 'Isla Bouvet', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(33, 'Brasil', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(34, 'Brunéi', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(35, 'Bulgaria', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(36, 'Burkina Faso', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(37, 'Burundi', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(38, 'Cabo Verde', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(39, 'Islas Caimán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(40, 'Camboya', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(41, 'Camerún', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(42, 'Canadá', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(43, 'República Centroafricana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(44, 'Chad', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(45, 'República Checa', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(46, 'Chile', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(47, 'China', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(48, 'Chipre', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(49, 'Isla de Navidad', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(50, 'Ciudad del Vaticano', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(51, 'Islas Cocos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(52, 'Colombia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(53, 'Comoras', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(54, 'República Democrática del Congo', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(55, 'Congo', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(56, 'Islas Cook', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(57, 'Corea del Norte', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(58, 'Corea del Sur', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(59, 'Costa de Marfil', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(60, 'Costa Rica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(61, 'Croacia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(62, 'Cuba', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(63, 'Dinamarca', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(64, 'Dominica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(65, 'República Dominicana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(66, 'Ecuador', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(67, 'Egipto', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(68, 'El Salvador', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(69, 'Emiratos Árabes Unidos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(70, 'Eritrea', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(71, 'Eslovaquia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(72, 'Eslovenia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(73, 'España', 1, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(74, 'Islas ultramarinas de Estados Unidos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(75, 'Estados Unidos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(76, 'Estonia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(77, 'Etiopía', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(78, 'Islas Feroe', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(79, 'Filipinas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(80, 'Finlandia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(81, 'Fiyi', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(82, 'Francia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(83, 'Gabón', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(84, 'Gambia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(85, 'Georgia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(86, 'Islas Georgias del Sur y Sandwich del Sur', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(87, 'Ghana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(88, 'Gibraltar', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(89, 'Granada', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(90, 'Grecia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(91, 'Groenlandia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(92, 'Guadalupe', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(93, 'Guam', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(94, 'Guatemala', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(95, 'Guayana Francesa', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(96, 'Guinea', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(97, 'Guinea Ecuatorial', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(98, 'Guinea-Bissau', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(99, 'Guyana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(100, 'Haití', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(101, 'Islas Heard y McDonald', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(102, 'Honduras', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(103, 'Hong Kong', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(104, 'Hungría', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(105, 'India', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(106, 'Indonesia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(107, 'Irán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(108, 'Iraq', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(109, 'Irlanda', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(110, 'Islandia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(111, 'Israel', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(112, 'Italia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(113, 'Jamaica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(114, 'Japón', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(115, 'Jordania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(116, 'Kazajstán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(117, 'Kenia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(118, 'Kirguistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(119, 'Kiribati', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(120, 'Kuwait', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(121, 'Laos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(122, 'Lesotho', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(123, 'Letonia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(124, 'Líbano', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(125, 'Liberia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(126, 'Libia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(127, 'Liechtenstein', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(128, 'Lituania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(129, 'Luxemburgo', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(130, 'Macao', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(131, 'ARY Macedonia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(132, 'Madagascar', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(133, 'Malasia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(134, 'Malawi', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(135, 'Maldivas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(136, 'Malí', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(137, 'Malta', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(138, 'Islas Malvinas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(139, 'Islas Marianas del Norte', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(140, 'Marruecos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(141, 'Islas Marshall', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(142, 'Martinica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(143, 'Mauricio', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(144, 'Mauritania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(145, 'Mayotte', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(146, 'México', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(147, 'Micronesia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(148, 'Moldavia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(149, 'Mónaco', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(150, 'Mongolia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(151, 'Montserrat', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(152, 'Mozambique', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(153, 'Myanmar', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(154, 'Namibia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(155, 'Nauru', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(156, 'Nepal', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(157, 'Nicaragua', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(158, 'Níger', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(159, 'Nigeria', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(160, 'Niue', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(161, 'Isla Norfolk', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(162, 'Noruega', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(163, 'Nueva Caledonia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(164, 'Nueva Zelanda', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(165, 'Omán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(166, 'Países Bajos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(167, 'Pakistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(168, 'Palau', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(169, 'Palestina', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(170, 'Panamá', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(171, 'Papúa Nueva Guinea', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(172, 'Paraguay', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(173, 'Perú', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(174, 'Islas Pitcairn', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(175, 'Polinesia Francesa', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(176, 'Polonia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(177, 'Portugal', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(178, 'Puerto Rico', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(179, 'Qatar', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(180, 'Reino Unido', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(181, 'Reunión', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(182, 'Ruanda', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(183, 'Rumania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(184, 'Rusia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(185, 'Sahara Occidental', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(186, 'Islas Salomón', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(187, 'Samoa', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(188, 'Samoa Americana', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(189, 'San Cristóbal y Nevis', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(190, 'San Marino', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(191, 'San Pedro y Miquelón', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(192, 'San Vicente y las Granadinas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(193, 'Santa Helena', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(194, 'Santa Lucía', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(195, 'Santo Tomé y Príncipe', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(196, 'Senegal', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(197, 'Serbia y Montenegro', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(198, 'Seychelles', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(199, 'Sierra Leona', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(200, 'Singapur', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(201, 'Siria', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(202, 'Somalia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(203, 'Sri Lanka', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(204, 'Suazilandia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(205, 'Sudáfrica', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(206, 'Sudán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(207, 'Suecia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(208, 'Suiza', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(209, 'Surinam', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(210, 'Svalbard y Jan Mayen', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(211, 'Tailandia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(212, 'Taiwán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(213, 'Tanzania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(214, 'Tayikistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(215, 'Territorio Británico del Océano Índico', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(216, 'Territorios Australes Franceses', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(217, 'Timor Oriental', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(218, 'Togo', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(219, 'Tokelau', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(220, 'Tonga', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(221, 'Trinidad y Tobago', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(222, 'Túnez', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(223, 'Islas Turcas y Caicos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(224, 'Turkmenistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(225, 'Turquía', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(226, 'Tuvalu', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(227, 'Ucrania', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(228, 'Uganda', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(229, 'Uruguay', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(230, 'Uzbekistán', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(231, 'Vanuatu', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(232, 'Venezuela', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(233, 'Vietnam', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(234, 'Islas Vírgenes Británicas', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(235, 'Islas Vírgenes de los Estados Unidos', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(236, 'Wallis y Futuna', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(237, 'Yemen', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(238, 'Yibuti', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(239, 'Zambia', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30'),
(240, 'Zimbabue', 0, '2016-02-02 18:33:30', '2016-02-02 18:33:30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `provincias`
--

CREATE TABLE `provincias` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provincia` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `pais_id` bigint(20) UNSIGNED NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:30'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `provincias`
--

INSERT INTO `provincias` (`id`, `provincia`, `pais_id`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'LAS PALMAS', 73, 1, '2015-12-10 17:07:20', '2015-12-15 21:49:16'),
(5, 'MEDELLIN', 52, 1, '2015-12-15 16:57:34', '2015-12-15 22:04:15'),
(6, 'BURGOS', 73, 1, '2015-12-15 21:42:23', '2015-12-15 21:42:23'),
(7, 'CADIZ', 73, 1, '2015-12-15 21:42:47', '2015-12-15 21:47:58'),
(8, 'LOGROÑO', 73, 1, '2015-12-15 21:43:07', '2015-12-15 21:48:18'),
(9, 'MURCIA', 73, 1, '2015-12-15 21:43:24', '2015-12-15 21:48:43'),
(10, 'CIUDAD REAL', 73, 1, '2015-12-15 21:43:38', '2015-12-15 21:43:38'),
(11, 'CÓRDOBA', 73, 1, '2015-12-15 21:43:52', '2015-12-15 21:43:52'),
(12, 'CÁCERES', 73, 1, '2015-12-15 21:44:20', '2015-12-15 22:03:36'),
(13, 'CUENCA', 73, 1, '2015-12-15 21:44:32', '2015-12-15 21:44:32'),
(15, 'ALBACETE', 73, 1, '2015-12-15 21:45:23', '2015-12-15 21:45:23'),
(16, 'ALMERÍA', 73, 1, '2015-12-15 21:45:36', '2015-12-15 21:45:36'),
(17, 'ASTORGA', 73, 1, '2015-12-15 21:45:48', '2015-12-15 21:45:48'),
(18, 'AVILA', 73, 1, '2015-12-15 21:45:59', '2015-12-15 21:45:59'),
(19, 'BADAJOZ', 73, 1, '2015-12-15 21:46:37', '2015-12-15 21:46:37'),
(20, 'BARCELONA', 73, 1, '2015-12-15 21:49:50', '2015-12-15 21:49:50'),
(22, 'GERONA', 73, 1, '2015-12-15 21:50:57', '2015-12-15 21:50:57'),
(23, 'MADRID', 73, 1, '2015-12-15 21:51:39', '2015-12-15 21:51:39'),
(24, 'GRANADA', 73, 1, '2015-12-15 21:51:56', '2015-12-15 21:51:56'),
(25, 'HUELVA', 73, 1, '2015-12-15 21:52:20', '2015-12-15 21:52:20'),
(26, 'HUESCA', 73, 1, '2015-12-15 21:52:35', '2015-12-15 21:52:35'),
(27, 'JAÉN', 73, 1, '2015-12-15 21:52:52', '2015-12-15 21:52:52'),
(28, 'LEÓN', 73, 1, '2015-12-15 21:53:19', '2015-12-15 21:53:19'),
(29, 'LÉRIDA', 73, 1, '2015-12-15 21:53:32', '2015-12-15 21:53:32'),
(30, 'LUGO', 73, 1, '2015-12-15 21:53:43', '2015-12-15 21:53:43'),
(31, 'MÁLAGA', 73, 1, '2015-12-15 21:53:56', '2015-12-15 21:53:56'),
(32, 'MALLORCA', 73, 1, '2015-12-15 21:54:15', '2015-12-15 21:54:15'),
(33, 'ORENSE', 73, 1, '2015-12-15 21:55:07', '2015-12-15 21:55:07'),
(34, 'ALICANTE', 73, 1, '2015-12-15 21:55:23', '2015-12-15 21:55:23'),
(35, 'SORIA', 73, 1, '2015-12-15 21:55:39', '2015-12-15 21:55:39'),
(37, 'PALENCIA', 73, 1, '2015-12-15 21:56:05', '2015-12-15 21:56:05'),
(38, 'NAVARRA', 73, 1, '2015-12-15 21:56:20', '2015-12-15 21:56:20'),
(39, 'SALAMANCA', 73, 1, '2015-12-15 21:56:51', '2015-12-15 21:56:51'),
(40, 'GUIPÚZCOA', 73, 1, '2015-12-15 21:57:24', '2015-12-15 21:57:24'),
(41, 'SANTANDER', 73, 1, '2015-12-15 21:57:42', '2015-12-15 21:57:42'),
(42, 'LA CORUÑA', 73, 1, '2015-12-15 21:57:59', '2015-12-15 21:57:59'),
(43, 'CASTELLÓN', 73, 1, '2015-12-15 21:58:21', '2015-12-15 21:58:21'),
(44, 'SEGOVIA', 73, 1, '2015-12-15 21:58:38', '2015-12-15 21:58:38'),
(45, 'SEVILLA', 73, 1, '2015-12-15 21:58:53', '2015-12-15 21:58:53'),
(46, 'GUADALAJARA', 73, 1, '2015-12-15 21:59:09', '2015-12-15 21:59:09'),
(47, 'ZARAGOZA', 73, 1, '2015-12-15 21:59:53', '2015-12-15 21:59:53'),
(48, 'TENERIFE', 73, 1, '2015-12-15 22:00:20', '2015-12-15 22:00:20'),
(49, 'TERUEL', 73, 1, '2015-12-15 22:00:34', '2015-12-15 22:00:34'),
(50, 'TOLEDO', 73, 1, '2015-12-15 22:00:49', '2015-12-15 22:00:49'),
(51, 'TARRAGONA', 73, 1, '2015-12-15 22:01:08', '2015-12-15 22:01:08'),
(52, 'PONTEVEDRA', 73, 1, '2015-12-15 22:01:29', '2015-12-15 22:01:29'),
(53, 'VALENCIA', 73, 1, '2015-12-15 22:01:44', '2015-12-15 22:01:44'),
(54, 'VALLADOLID', 73, 1, '2015-12-15 22:02:02', '2015-12-15 22:02:02'),
(55, 'ALAVA', 73, 1, '2015-12-15 22:02:19', '2015-12-15 22:02:19'),
(56, 'ZAMORA', 73, 1, '2015-12-15 22:02:34', '2015-12-15 22:02:34'),
(60, 'VIZCAYA', 73, 1, '2015-12-15 22:52:21', '2015-12-15 22:52:21'),
(61, 'DIVINOPOLIS MG', 33, 1, '2015-12-16 16:54:10', '2015-12-16 16:54:10'),
(62, 'POUSO ALEGRE', 33, 1, '2015-12-16 16:54:53', '2015-12-16 16:54:53'),
(63, 'MARIANA', 33, 1, '2015-12-16 16:55:18', '2015-12-16 16:55:18'),
(64, 'PARANÁ', 33, 1, '2015-12-16 16:55:42', '2015-12-16 16:55:42'),
(65, 'OURINHOS', 33, 1, '2015-12-16 16:56:01', '2015-12-16 16:56:01'),
(66, 'JALES', 33, 1, '2015-12-16 16:56:15', '2015-12-16 16:56:15'),
(67, 'JUNDIAÍ', 33, 1, '2015-12-16 16:57:01', '2015-12-16 16:57:01'),
(68, 'APUCARANA', 33, 1, '2015-12-16 16:57:20', '2015-12-16 16:57:20'),
(69, 'NOVA IGUAZÚ', 33, 1, '2015-12-16 16:57:55', '2015-12-16 16:57:55'),
(70, 'CAXIAS DO SUL', 33, 1, '2015-12-16 16:58:14', '2015-12-17 09:46:56'),
(71, 'FLORIANAPOLIS', 33, 1, '2015-12-16 16:58:41', '2015-12-16 16:58:41'),
(72, 'GOIANIA', 33, 1, '2015-12-16 16:59:07', '2015-12-16 16:59:07'),
(74, 'ARACATUBA', 33, 1, '2015-12-16 16:59:51', '2015-12-16 16:59:51'),
(75, 'CURITIBA PR', 33, 1, '2015-12-16 17:00:29', '2015-12-16 17:00:29'),
(76, 'RIO DO SUL', 33, 1, '2015-12-16 17:01:00', '2015-12-16 17:01:00'),
(77, 'SANTA MARÍA RS', 33, 1, '2015-12-16 17:01:24', '2015-12-16 17:01:24'),
(78, 'ITUMBIARA', 33, 1, '2015-12-16 17:01:48', '2015-12-16 17:01:48'),
(79, 'MACEIÓ AL', 33, 1, '2015-12-16 17:02:15', '2015-12-16 17:02:15'),
(80, 'RIO DE JANEIRO RJ', 33, 1, '2015-12-16 17:02:33', '2015-12-16 17:02:33'),
(81, 'VILA VELHA ES', 33, 1, '2015-12-16 17:03:12', '2015-12-16 17:03:12'),
(82, 'ANÁPOLIS-GOIÁS', 38, 1, '2015-12-16 17:03:52', '2015-12-16 17:03:52'),
(83, 'ARACAJU-SERGIPE', 33, 1, '2015-12-16 17:04:20', '2015-12-16 17:04:20'),
(84, 'BRASILIA DF', 33, 1, '2015-12-16 17:04:39', '2015-12-16 17:04:39'),
(85, 'ITAPETININGA ', 33, 1, '2015-12-16 17:05:19', '2015-12-16 17:05:19'),
(86, 'BRAGANCA PAULISTA SP', 33, 1, '2015-12-16 17:05:47', '2015-12-16 17:05:47'),
(87, 'CAMPO MOURAO', 33, 1, '2015-12-16 17:06:16', '2015-12-16 17:06:16'),
(88, 'JATAÍ GO', 33, 1, '2015-12-16 17:06:42', '2015-12-16 17:06:42'),
(89, 'PETROPOLIS RJ', 33, 1, '2015-12-16 17:07:02', '2015-12-16 17:07:02'),
(90, 'URUGUAIANIA RS', 33, 1, '2015-12-16 17:07:35', '2015-12-16 17:07:35'),
(91, 'VACARIA', 33, 1, '2015-12-16 17:07:59', '2015-12-16 17:07:59'),
(92, 'PARANAVAÍ', 33, 1, '2015-12-16 17:08:22', '2015-12-16 17:08:22'),
(93, 'SAN JOSE DO RIO PRETO SP', 33, 1, '2015-12-16 17:08:44', '2015-12-16 17:08:44'),
(94, 'LEOPOLDINA MG', 33, 1, '2015-12-16 17:09:13', '2015-12-16 17:09:13'),
(95, 'PELOTAS RS', 33, 1, '2015-12-16 17:09:28', '2015-12-16 17:09:28'),
(96, 'CUIABÁ', 33, 1, '2015-12-16 17:09:51', '2015-12-16 17:09:51'),
(97, 'SOROCABA SP', 33, 1, '2015-12-16 17:10:07', '2015-12-16 17:10:07'),
(98, 'TAUBATÉ SP', 33, 1, '2015-12-16 17:10:25', '2015-12-17 09:18:23'),
(100, 'PARANATINGA MT', 33, 1, '2015-12-16 17:11:12', '2015-12-16 17:11:12'),
(101, 'GOIÁS', 33, 1, '2015-12-16 20:32:38', '2015-12-16 20:32:38'),
(102, 'TEGUCIGALPA', 102, 1, '2015-12-17 10:54:36', '2015-12-17 10:54:36'),
(103, 'QUITO', 66, 1, '2015-12-17 10:57:18', '2015-12-17 10:57:18'),
(106, 'SAN SALVADOR', 68, 1, '2015-12-17 11:02:38', '2015-12-17 11:02:38'),
(107, 'PONCE', 178, 1, '2015-12-17 11:05:11', '2015-12-17 11:05:11'),
(108, 'TOKYO', 114, 1, '2015-12-17 11:07:56', '2015-12-17 11:07:56'),
(109, 'RUMANÍA', 183, 1, '2015-12-17 11:43:41', '2015-12-17 11:43:41'),
(110, 'SANTIAGO', 46, 1, '2015-12-17 12:25:50', '2015-12-17 12:25:50'),
(111, 'VALPARAÍSO', 46, 1, '2015-12-17 12:26:07', '2015-12-17 12:26:07'),
(113, 'SANTIAGO ZO', 46, 1, '2015-12-17 12:27:04', '2015-12-17 12:27:04'),
(114, 'LOS ANGELES', 46, 1, '2015-12-17 12:27:23', '2015-12-17 12:27:23'),
(115, 'HERRERA', 170, 1, '2015-12-17 12:27:43', '2015-12-17 12:27:43'),
(116, 'PANAMÁ', 170, 1, '2015-12-17 12:28:04', '2015-12-17 12:28:04'),
(117, 'AREQUIPA', 173, 1, '2015-12-17 12:28:27', '2015-12-17 12:28:27'),
(118, 'CHINCHA', 173, 1, '2015-12-17 12:28:51', '2015-12-17 12:28:51'),
(119, 'LIMA', 173, 1, '2015-12-17 12:29:09', '2015-12-17 12:29:09'),
(120, 'SANTIAGO RP', 65, 1, '2015-12-17 12:29:31', '2015-12-17 12:29:31'),
(121, 'LA VEGA', 65, 1, '2015-12-17 12:30:32', '2015-12-17 12:30:32'),
(122, 'MERCEDES', 229, 1, '2015-12-17 12:31:07', '2015-12-17 12:31:07'),
(123, 'MONTEVIDEO', 229, 1, '2015-12-17 12:31:27', '2015-12-17 12:31:27'),
(124, 'SALTO', 229, 1, '2015-12-17 12:31:44', '2015-12-17 12:31:44'),
(125, 'SANTO DOMINGO', 65, 1, '2015-12-17 12:32:13', '2015-12-17 12:32:13'),
(127, 'CAMDEM', 16, 1, '2015-12-17 16:07:51', '2015-12-17 16:07:51'),
(128, 'BATHURST', 16, 1, '2015-12-17 16:08:18', '2015-12-17 16:08:18'),
(129, 'KENTIVILLE NS B4 3x3', 42, 1, '2015-12-17 16:10:22', '2015-12-17 16:10:22'),
(130, 'VICTORIA BC  V8V3V9', 42, 1, '2015-12-17 16:11:06', '2015-12-17 16:11:06'),
(131, 'COQUITLAM BC', 42, 1, '2015-12-17 16:11:40', '2015-12-17 16:11:40'),
(132, 'JESU', 58, 1, '2015-12-17 16:14:26', '2015-12-17 16:14:26'),
(133, 'TAEGU', 58, 1, '2015-12-17 16:14:55', '2015-12-17 16:14:55'),
(134, 'SEOUL', 58, 1, '2015-12-17 16:15:18', '2015-12-17 16:15:18'),
(135, 'BRNO', 45, 1, '2015-12-17 16:16:05', '2015-12-17 16:16:05'),
(136, 'TEXAS', 75, 1, '2015-12-17 20:10:28', '2015-12-17 20:10:28'),
(137, 'FLORIDA', 75, 1, '2015-12-17 20:10:54', '2015-12-17 20:10:54'),
(139, 'HAWESVILLE', 75, 1, '2015-12-17 20:12:10', '2015-12-17 20:12:10'),
(140, 'NEW YORK', 75, 1, '2015-12-17 20:12:26', '2015-12-17 20:12:26'),
(141, 'SAN DIEGO', 75, 1, '2015-12-17 20:12:47', '2015-12-17 20:12:47'),
(142, 'OKHALOMA', 75, 1, '2015-12-17 20:13:18', '2015-12-17 20:13:18'),
(143, 'COLORADO', 75, 1, '2015-12-17 20:13:34', '2015-12-17 20:13:34'),
(144, 'ARKANSAS', 75, 1, '2015-12-17 20:13:50', '2015-12-17 20:13:50'),
(145, 'MANCHESTER', 75, 1, '2015-12-17 20:14:32', '2015-12-17 20:14:32'),
(146, 'CALIFORNIA', 75, 1, '2015-12-17 20:14:46', '2015-12-17 20:14:46'),
(147, 'PHOENIX', 75, 1, '2015-12-17 20:15:06', '2015-12-17 20:15:06'),
(150, 'NUEVO LEÓN', 146, 1, '2015-12-17 20:56:56', '2015-12-17 20:56:56'),
(151, 'TAMAULIPAS', 146, 1, '2015-12-17 20:57:18', '2015-12-17 20:57:18'),
(153, 'GUANAJUATO', 146, 1, '2015-12-17 20:58:01', '2015-12-17 20:58:01'),
(154, 'DURANGO', 146, 1, '2015-12-17 20:58:23', '2015-12-17 20:58:23'),
(155, 'MICHOACAN', 146, 1, '2015-12-17 20:58:38', '2015-12-17 20:58:38'),
(156, 'JALISCO', 146, 1, '2015-12-17 20:58:51', '2015-12-17 20:58:51'),
(157, 'YUCATÁN', 146, 1, '2015-12-17 20:59:10', '2015-12-17 20:59:10'),
(158, 'TOLUCA', 146, 1, '2015-12-17 20:59:35', '2015-12-17 20:59:35'),
(159, 'HIDALGO', 146, 1, '2015-12-17 20:59:55', '2015-12-17 20:59:55'),
(160, 'CHIHUAHUA', 146, 1, '2015-12-17 21:00:18', '2015-12-17 21:00:18'),
(161, 'CIUDAD ALTAMIRANO', 146, 1, '2015-12-17 21:00:48', '2015-12-17 21:00:48'),
(162, 'XALAPA', 146, 1, '2015-12-17 21:01:15', '2015-12-17 21:01:15'),
(163, 'COAHUILA', 146, 1, '2015-12-17 21:01:43', '2015-12-17 21:01:43'),
(164, 'PUEBLA', 146, 1, '2015-12-17 21:01:59', '2015-12-17 21:01:59'),
(165, 'SONORA', 146, 1, '2015-12-17 21:02:11', '2015-12-17 21:02:11'),
(167, 'PIEDRAS NEGRAS', 146, 1, '2015-12-17 21:03:03', '2015-12-17 21:03:03'),
(168, 'GUADALAJARA', 146, 1, '2015-12-17 21:12:52', '2015-12-19 08:13:40'),
(169, 'PORTO', 177, 1, '2015-12-18 07:00:55', '2015-12-18 07:00:55'),
(170, 'AZORES', 177, 1, '2015-12-18 07:01:15', '2015-12-18 07:01:15'),
(171, 'MADEIRA', 177, 1, '2015-12-18 07:01:51', '2015-12-18 07:01:51'),
(172, 'AVEIRO', 177, 1, '2015-12-18 07:02:10', '2015-12-18 07:02:10'),
(173, 'VIANA DE CASTELO', 177, 1, '2015-12-18 07:02:31', '2015-12-18 07:02:31'),
(174, 'COIMBRA', 177, 1, '2015-12-18 07:02:46', '2015-12-18 07:02:46'),
(175, 'BRAGANZA MIRANDA', 177, 1, '2015-12-18 07:03:07', '2015-12-18 07:03:07'),
(176, 'VISEU', 177, 1, '2015-12-18 07:03:23', '2015-12-18 07:03:23'),
(177, 'BRAGA', 177, 1, '2015-12-18 07:03:40', '2015-12-18 07:03:40'),
(178, 'LAMEGO', 177, 1, '2015-12-18 07:03:55', '2015-12-18 07:03:55'),
(179, 'CEIRA', 177, 1, '2015-12-18 07:04:12', '2015-12-18 07:04:12'),
(180, 'TORRES VEDRAS', 177, 1, '2015-12-18 07:04:29', '2015-12-18 07:04:29'),
(181, 'MENDOZA', 13, 1, '2015-12-18 09:00:37', '2015-12-18 09:00:37'),
(183, 'MERCEDES.', 13, 1, '2015-12-18 09:01:44', '2015-12-18 09:01:44'),
(184, 'AVELLANEDA', 13, 1, '2015-12-18 09:02:02', '2015-12-18 09:02:02'),
(185, 'BUENOS AIRES', 13, 1, '2015-12-18 09:02:14', '2015-12-18 09:02:14'),
(186, 'BAHÍA BLANCA', 13, 1, '2015-12-18 09:02:30', '2015-12-18 09:02:30'),
(187, 'RESISTENCIA-CHACO', 13, 1, '2015-12-18 09:02:57', '2015-12-18 09:02:57'),
(188, 'CORRIENTES', 13, 1, '2015-12-18 09:03:18', '2015-12-18 09:03:18'),
(189, 'CORDOBA', 13, 1, '2015-12-18 09:03:32', '2015-12-19 08:12:24'),
(190, 'MERLO', 13, 1, '2015-12-18 09:03:52', '2015-12-18 09:03:52'),
(191, 'SANTA FE', 13, 1, '2015-12-18 09:04:06', '2015-12-18 09:04:06'),
(194, 'CORDOBA', 13, 1, '2015-12-18 09:04:50', '2015-12-19 08:12:45'),
(195, 'TUCUMAN', 13, 1, '2015-12-18 09:05:06', '2015-12-18 09:05:06'),
(197, 'SAN ISIDRO', 13, 1, '2015-12-18 09:05:40', '2015-12-18 09:05:40'),
(198, '9 DE JULIO', 13, 1, '2015-12-18 09:05:55', '2015-12-18 09:05:55'),
(199, 'SAN RAFAEL', 13, 1, '2015-12-18 09:06:11', '2015-12-18 09:06:11'),
(200, 'MAR DEL PLATA', 13, 1, '2015-12-18 09:06:25', '2015-12-18 09:06:25'),
(201, 'RIO NEGRO', 13, 1, '2015-12-18 09:06:44', '2015-12-18 09:06:44'),
(202, 'VIRGEN DEL ROSARIO S.N.', 13, 1, '2015-12-18 09:07:05', '2015-12-18 09:07:05'),
(204, 'LA PAMPA', 13, 1, '2015-12-18 09:07:40', '2015-12-18 09:07:40'),
(205, 'SANTIAGO DEL ESTERO', 13, 1, '2015-12-18 09:07:57', '2015-12-18 09:07:57'),
(206, 'FERMO', 112, 1, '2015-12-18 12:12:03', '2015-12-18 12:12:03'),
(207, 'GENOVA', 112, 1, '2015-12-18 12:12:18', '2015-12-18 12:12:18'),
(208, 'TRAPANI', 112, 1, '2015-12-18 12:12:45', '2015-12-18 12:12:45'),
(209, 'VICENZA', 112, 1, '2015-12-18 12:13:12', '2015-12-18 12:13:12'),
(210, 'AVERSA', 112, 1, '2015-12-18 12:13:26', '2015-12-18 12:13:26'),
(211, 'FIRENZE', 112, 1, '2015-12-18 12:13:40', '2015-12-18 12:13:40'),
(212, 'PENITRO FORMA', 112, 1, '2015-12-18 12:14:21', '2015-12-18 12:14:21'),
(213, 'ROMA', 112, 1, '2015-12-18 12:14:38', '2015-12-18 12:14:38'),
(214, 'PADOVA', 112, 1, '2015-12-18 12:14:53', '2015-12-18 12:14:53'),
(215, 'PERUGIA', 112, 1, '2015-12-18 12:15:08', '2015-12-18 12:15:08'),
(216, 'RAGUSA', 112, 1, '2015-12-18 12:15:24', '2015-12-18 12:15:24'),
(217, 'RAVENA', 112, 1, '2015-12-18 12:15:43', '2015-12-18 12:15:43'),
(218, 'BOLOGNA', 112, 1, '2015-12-18 12:15:57', '2015-12-18 12:15:57'),
(219, 'CAGLIARI', 112, 1, '2015-12-18 12:16:11', '2015-12-18 12:16:11'),
(220, 'ORISTANO', 112, 1, '2015-12-18 12:16:23', '2015-12-18 12:16:23'),
(221, 'JESI', 112, 1, '2015-12-18 12:16:35', '2015-12-18 12:16:35'),
(222, 'ASCOLI PICENO', 112, 1, '2015-12-18 12:16:52', '2015-12-18 12:16:52'),
(223, 'BENEVENTO', 112, 1, '2015-12-18 12:17:07', '2015-12-18 12:17:07'),
(224, 'CALTAGIRONE', 112, 1, '2015-12-18 12:17:22', '2015-12-18 12:17:22'),
(225, 'PRATO', 112, 1, '2015-12-18 12:17:35', '2015-12-18 12:17:35'),
(226, 'ASSISI', 112, 1, '2015-12-18 12:17:59', '2015-12-18 12:17:59'),
(227, 'NARDO GALLIPOLI', 112, 1, '2015-12-18 12:18:22', '2015-12-18 12:18:22'),
(228, 'ORIA', 112, 1, '2015-12-18 12:18:36', '2015-12-18 12:18:36'),
(229, 'NUORO', 112, 1, '2015-12-18 12:18:48', '2015-12-18 12:18:48'),
(230, 'MACERATA', 112, 1, '2015-12-18 12:19:08', '2015-12-18 12:19:08'),
(231, 'SIRACUSA', 112, 1, '2015-12-18 12:19:21', '2015-12-18 12:19:21'),
(233, 'LECCE', 112, 1, '2015-12-18 12:20:01', '2015-12-18 12:20:01'),
(234, 'SASSARI', 112, 1, '2015-12-18 12:20:14', '2015-12-18 12:20:14'),
(235, 'CONSENZA', 112, 1, '2015-12-18 12:20:31', '2015-12-18 12:20:31'),
(236, 'PESCARA', 112, 1, '2015-12-18 12:20:43', '2015-12-18 12:20:43'),
(237, 'ANGELI ASSISI', 112, 1, '2015-12-18 12:21:20', '2015-12-18 12:21:20'),
(238, 'BIELLA', 112, 1, '2015-12-18 12:21:51', '2015-12-18 12:21:51'),
(239, 'BRINDISI', 112, 1, '2015-12-18 12:22:08', '2015-12-18 12:22:08'),
(240, 'COSENZA BISIGNANO', 112, 1, '2015-12-18 12:22:32', '2015-12-18 12:22:32'),
(241, 'FERRARA', 112, 1, '2015-12-18 12:22:44', '2015-12-18 12:22:44'),
(242, 'FORMIA', 112, 1, '2015-12-18 12:23:08', '2015-12-18 12:23:08'),
(243, 'MODENA', 112, 1, '2015-12-18 12:23:20', '2015-12-18 12:23:20'),
(244, 'NICHELINO', 112, 1, '2015-12-18 12:23:35', '2015-12-18 12:23:35'),
(245, 'OCCHIEPPO INFERIORE', 112, 1, '2015-12-18 12:23:55', '2015-12-18 12:52:12'),
(246, 'PATERNÓ', 112, 1, '2015-12-18 12:24:12', '2015-12-18 12:24:12'),
(247, 'TERNI', 112, 1, '2015-12-18 12:26:51', '2015-12-18 12:26:51'),
(248, 'TORINO', 112, 1, '2015-12-18 12:27:16', '2015-12-18 12:27:16'),
(250, 'TRENTO', 112, 1, '2015-12-18 12:28:12', '2015-12-18 12:28:12'),
(251, 'TREVISO', 112, 1, '2015-12-18 12:28:26', '2015-12-18 12:28:26'),
(252, 'TRIESTE', 112, 1, '2015-12-18 12:28:41', '2015-12-18 12:28:41'),
(259, 'BRNO', 4, 1, '2015-12-19 08:48:28', '2015-12-19 08:48:28'),
(260, 'PRIMERA', 242, 1, '2015-12-28 15:49:20', '2015-12-28 15:49:20'),
(261, 'ASTURIAS', 73, 1, '2015-12-31 09:20:02', '2015-12-31 09:20:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rol` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `peso` int(11) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:33',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:33'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id`, `rol`, `peso`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'visitante', 100, 1, '2016-02-02 18:33:33', '2016-02-02 18:33:33'),
(2, 'registrado', 200, 1, '2016-02-02 18:33:33', '2016-02-02 18:33:33'),
(3, 'autorizado', 300, 1, '2016-02-02 18:33:33', '2016-02-02 18:33:33'),
(4, 'administrador', 400, 1, '2016-02-02 18:33:33', '2016-02-02 18:33:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_enviadas`
--

CREATE TABLE `solicitudes_enviadas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comunidad_id` bigint(20) UNSIGNED NOT NULL,
  `aceptada` tinyint(1) NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:41',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:41'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_enviadas_cursillos`
--

CREATE TABLE `solicitudes_enviadas_cursillos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `solicitud_id` bigint(20) UNSIGNED NOT NULL,
  `comunidad_id` bigint(20) UNSIGNED NOT NULL,
  `cursillo_id` bigint(20) UNSIGNED NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:45',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:45'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_recibidas`
--

CREATE TABLE `solicitudes_recibidas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comunidad_id` bigint(20) UNSIGNED NOT NULL,
  `aceptada` tinyint(1) NOT NULL DEFAULT '1',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:44',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:44'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes_recibidas_cursillos`
--

CREATE TABLE `solicitudes_recibidas_cursillos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `solicitud_id` bigint(20) UNSIGNED NOT NULL,
  `comunidad_id` bigint(20) UNSIGNED NOT NULL,
  `cursillo_id` bigint(20) UNSIGNED NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:45',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:45'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_comunicaciones_preferidas`
--

CREATE TABLE `tipos_comunicaciones_preferidas` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `comunicacion_preferida` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tipos_comunicaciones_preferidas`
--

INSERT INTO `tipos_comunicaciones_preferidas` (`id`, `comunicacion_preferida`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Carta', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35'),
(2, 'Email', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_participantes`
--

CREATE TABLE `tipos_participantes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipo_participante` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tipos_participantes`
--

INSERT INTO `tipos_participantes` (`id`, `tipo_participante`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Hombre', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35'),
(2, 'Mujer', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35'),
(3, 'Mixto', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_secretariados`
--

CREATE TABLE `tipos_secretariados` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tipo_secretariado` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35',
  `updated_at` timestamp NOT NULL DEFAULT '2016-02-02 18:33:35'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `tipos_secretariados`
--

INSERT INTO `tipos_secretariados` (`id`, `tipo_secretariado`, `activo`, `created_at`, `updated_at`) VALUES
(1, 'Secretariado Diocesano', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35'),
(2, 'Secretariado Arquidiocesano', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35'),
(3, 'Grupo Ejecutivo Diocesano', 1, '2016-02-02 18:33:35', '2016-02-02 18:33:35');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `foto` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'default.png',
  `rol_id` bigint(20) UNSIGNED NOT NULL DEFAULT '2',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `confirmado` tinyint(1) DEFAULT '0',
  `codigo_confirmacion` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `fullname`, `name`, `email`, `password`, `foto`, `rol_id`, `activo`, `remember_token`, `created_at`, `updated_at`, `confirmado`, `codigo_confirmacion`) VALUES
(1, 'Antonio Becerra Aleman', 'Antonio', 'antonio@gmail.com', '$2y$10$lBxVksL9qnry.BUoMFJVVerxApVdKx3Fba3PbCyMNNUVtQMiebpRO', 'default.png', 4, 1, NULL, '2016-02-02 18:34:03', '2016-02-02 18:34:03', 0, NULL),
(2, 'Francisco Luis Mentado Manzanares', 'Fmentado', 'a@a.es', '$2y$10$s31YtBy8mA/QgJ7HA.EDiOMonftPevoey5rgTr1GqDhrJ3afL4hxe', 'default.png', 4, 0, 'vmsNMeBzhUNXKWI3y9LsHtnqVW9HNTxShhvuK8VrbSbFra8LupDiJiz9HPzQ', '2016-02-02 18:34:03', '2016-02-02 22:37:03', 0, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `colores`
--
ALTER TABLE `colores`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `comunidades`
--
ALTER TABLE `comunidades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comunidades_tipo_secretariado_id_foreign` (`tipo_secretariado_id`),
  ADD KEY `comunidades_pais_id_foreign` (`pais_id`),
  ADD KEY `comunidades_provincia_id_foreign` (`provincia_id`),
  ADD KEY `comunidades_localidad_id_foreign` (`localidad_id`),
  ADD KEY `comunidades_tipo_comunicacion_preferida_id_foreign` (`tipo_comunicacion_preferida_id`);

--
-- Indices de la tabla `cursillos`
--
ALTER TABLE `cursillos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cursillos_comunidad_id_foreign` (`comunidad_id`),
  ADD KEY `cursillos_tipo_participante_id_foreign` (`tipo_participante_id`);

--
-- Indices de la tabla `localidades`
--
ALTER TABLE `localidades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `localidades_provincia_id_foreign` (`provincia_id`);

--
-- Indices de la tabla `paises`
--
ALTER TABLE `paises`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `paises_pais_unique` (`pais`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indices de la tabla `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `provincias_pais_id_foreign` (`pais_id`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudes_enviadas`
--
ALTER TABLE `solicitudes_enviadas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitudes_enviadas_comunidad_id_foreign` (`comunidad_id`);

--
-- Indices de la tabla `solicitudes_enviadas_cursillos`
--
ALTER TABLE `solicitudes_enviadas_cursillos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitudes_enviadas_cursillos_solicitud_id_foreign` (`solicitud_id`);

--
-- Indices de la tabla `solicitudes_recibidas`
--
ALTER TABLE `solicitudes_recibidas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitudes_recibidas_comunidad_id_foreign` (`comunidad_id`);

--
-- Indices de la tabla `solicitudes_recibidas_cursillos`
--
ALTER TABLE `solicitudes_recibidas_cursillos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solicitudes_recibidas_cursillos_solicitud_id_foreign` (`solicitud_id`);

--
-- Indices de la tabla `tipos_comunicaciones_preferidas`
--
ALTER TABLE `tipos_comunicaciones_preferidas`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos_participantes`
--
ALTER TABLE `tipos_participantes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `tipos_secretariados`
--
ALTER TABLE `tipos_secretariados`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `users_rol_id_foreign` (`rol_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `colores`
--
ALTER TABLE `colores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
--
-- AUTO_INCREMENT de la tabla `comunidades`
--
ALTER TABLE `comunidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;
--
-- AUTO_INCREMENT de la tabla `cursillos`
--
ALTER TABLE `cursillos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT de la tabla `localidades`
--
ALTER TABLE `localidades`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=314;
--
-- AUTO_INCREMENT de la tabla `paises`
--
ALTER TABLE `paises`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;
--
-- AUTO_INCREMENT de la tabla `provincias`
--
ALTER TABLE `provincias`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=262;
--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `solicitudes_enviadas`
--
ALTER TABLE `solicitudes_enviadas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `solicitudes_enviadas_cursillos`
--
ALTER TABLE `solicitudes_enviadas_cursillos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `solicitudes_recibidas`
--
ALTER TABLE `solicitudes_recibidas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `solicitudes_recibidas_cursillos`
--
ALTER TABLE `solicitudes_recibidas_cursillos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `tipos_comunicaciones_preferidas`
--
ALTER TABLE `tipos_comunicaciones_preferidas`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `tipos_participantes`
--
ALTER TABLE `tipos_participantes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `tipos_secretariados`
--
ALTER TABLE `tipos_secretariados`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `comunidades`
--
ALTER TABLE `comunidades`
  ADD CONSTRAINT `comunidades_localidad_id_foreign` FOREIGN KEY (`localidad_id`) REFERENCES `localidades` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `comunidades_pais_id_foreign` FOREIGN KEY (`pais_id`) REFERENCES `paises` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `comunidades_provincia_id_foreign` FOREIGN KEY (`provincia_id`) REFERENCES `provincias` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `comunidades_tipo_comunicacion_preferida_id_foreign` FOREIGN KEY (`tipo_comunicacion_preferida_id`) REFERENCES `tipos_comunicaciones_preferidas` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `comunidades_tipo_secretariado_id_foreign` FOREIGN KEY (`tipo_secretariado_id`) REFERENCES `tipos_secretariados` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `cursillos`
--
ALTER TABLE `cursillos`
  ADD CONSTRAINT `cursillos_comunidad_id_foreign` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `cursillos_tipo_participante_id_foreign` FOREIGN KEY (`tipo_participante_id`) REFERENCES `tipos_participantes` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `localidades`
--
ALTER TABLE `localidades`
  ADD CONSTRAINT `localidades_provincia_id_foreign` FOREIGN KEY (`provincia_id`) REFERENCES `provincias` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `provincias`
--
ALTER TABLE `provincias`
  ADD CONSTRAINT `provincias_pais_id_foreign` FOREIGN KEY (`pais_id`) REFERENCES `paises` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitudes_enviadas`
--
ALTER TABLE `solicitudes_enviadas`
  ADD CONSTRAINT `solicitudes_enviadas_comunidad_id_foreign` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitudes_enviadas_cursillos`
--
ALTER TABLE `solicitudes_enviadas_cursillos`
  ADD CONSTRAINT `solicitudes_enviadas_cursillos_solicitud_id_foreign` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_enviadas` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitudes_recibidas`
--
ALTER TABLE `solicitudes_recibidas`
  ADD CONSTRAINT `solicitudes_recibidas_comunidad_id_foreign` FOREIGN KEY (`comunidad_id`) REFERENCES `comunidades` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `solicitudes_recibidas_cursillos`
--
ALTER TABLE `solicitudes_recibidas_cursillos`
  ADD CONSTRAINT `solicitudes_recibidas_cursillos_solicitud_id_foreign` FOREIGN KEY (`solicitud_id`) REFERENCES `solicitudes_recibidas` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_rol_id_foreign` FOREIGN KEY (`rol_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
